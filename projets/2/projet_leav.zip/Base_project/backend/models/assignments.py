"""
@AI_SPACE
@purpose   : Modèles Pydantic pour les assignations, véhicules et préleveurs.
@logic     : Structure le retour JSON attendu par le frontend.
@decisions : Utilisation de modèles précis (Vehicle, Collector) et permissifs (Dict[str, Any] si besoin) pour s'adapter à l'existant sans le briser.
@references: https://docs.pydantic.dev/latest/
"""
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

class Collector(BaseModel):
    id: str
    name: str
    zone: str
    avatar: str
    phone: str
    status: str

class Vehicle(BaseModel):
    id: str
    plate: str
    model: str
    type: str
    status: str
    capacity: str
    fuelType: str
    collector_pref: Optional[str] = None

class Assignment(BaseModel):
    id: str
    date: str
    dayName: str
    collector: Dict[str, Any]
    vehicle: Dict[str, Any]
    zone: str
    tourneeType: str
    startTime: str
    endTime: str
    stops: int
    status: str

class Stats(BaseModel):
    totalCollectors: int
    activeCollectors: int
    totalVehicles: int
    todayAssignments: int
    weekAssignments: int
    unassignedTotal: int
    
class AssignmentsResponse(BaseModel):
    assignments: List[Assignment]
    stats: Optional[Stats] = None
    error: Optional[str] = None
