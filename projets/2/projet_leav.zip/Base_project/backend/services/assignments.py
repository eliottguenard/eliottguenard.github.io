"""
@AI_SPACE
@purpose   : Logique métier pour la lecture et le calcul des affectations, véhicules, et préleveurs.
@logic     : Lit les fichiers Excel (vehicules, attribution_vehicules) via Pandas et construit les structures de données (listes/dict) prêtes à être renvoyées par le routeur.
@decisions : Extraction totale du routeur pour respecter l'architecture Modulaire. Pas de HTTPException ici (laissé au routeur).
@references: https://pandas.pydata.org/
"""
import pandas as pd
import os
from datetime import datetime, timedelta

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "_data")

def clean_nan(val, default=""):
    if pd.isna(val):
        return default
    return str(val)

def load_real_collectors():
    vehic_path = os.path.join(DATA_DIR, "vehicules.xlsx")
    collectors_map = {}
    if os.path.exists(vehic_path):
        try:
            df_veh = pd.read_excel(vehic_path, sheet_name="préférence", skiprows=1)
            df_veh.columns = df_veh.columns.str.replace("[\n\r]", " ", regex=True).str.replace(r"\s+", " ", regex=True)
            for _, row in df_veh.iterrows():
                pr = clean_nan(row.get("Paraphe", ""))
                nom = clean_nan(row.get("Nom_Prenom", ""))
                if pr:
                    collectors_map[pr] = {
                        "id": pr,
                        "name": nom if nom else pr,
                        "zone": "Général",
                        "avatar": "🧑‍🔬",
                        "phone": "Non renseigné",
                        "status": "actif"
                    }
        except Exception as e:
            print("Error loading collectors:", e)
    return collectors_map

def load_real_vehicles_map():
    vehic_path = os.path.join(DATA_DIR, "vehicules.xlsx")
    vehicles_map = {}
    if os.path.exists(vehic_path):
        try:
            df_veh = pd.read_excel(vehic_path, sheet_name="préférence", skiprows=1)
            df_veh.columns = df_veh.columns.str.replace("[\n\r]", " ", regex=True).str.replace(r"\s+", " ", regex=True)
            for _, row in df_veh.iterrows():
                plate = clean_nan(row.get("VEHICULE IMMATRICULATION", ""))
                model = clean_nan(row.get("type de véhicule", ""))
                if plate:
                    vehicles_map[plate] = {
                        "id": plate, "plate": plate, "model": model, 
                        "type": "TBA", "status": "disponible", 
                        "capacity": "Standard", "fuelType": "Standard"
                    }
        except Exception as e:
            pass
    return vehicles_map

def get_assignments_data() -> dict:
    attr_path = os.path.join(DATA_DIR, "attribution_vehicules.xlsx")
    if not os.path.exists(attr_path):
        return {"assignments": [], "stats": {}}
        
    try:
        xls = pd.ExcelFile(attr_path)
        df_resume = pd.read_excel(xls, "Résumé Quotidien")
        df_tours = pd.read_excel(xls, "Attribution")
        
        assignments = []
        today = datetime.now().date()
        
        real_collectors = load_real_collectors()
        real_vehicles = load_real_vehicles_map()
        
        for idx, row in df_resume.iterrows():
            date_str = str(row["DATE"]).split(" ")[0]
            try:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            except:
                date_obj = today
                
            day_name = date_obj.strftime("%A")
            
            pr = str(row["PRELEVEUR"])
            veh = str(row["VEHICULE_ASSIGNE"])
            contraintes = str(row["CONTRAINTES_JOURNEE"])
            
            collector = real_collectors.get(pr, {
                "id": pr, "name": pr, "zone": "Général", "avatar": "🧑‍🔬", "phone": "Non renseigné", "status": "actif"
            })
            
            vehicle = real_vehicles.get(veh, {
                "id": veh, "plate": veh, "model": "Véhicule du parc", "type": "TBA", 
                "status": "disponible", "capacity": "Standard", "fuelType": "Standard"
            })
            if veh == "AUCUN DISPONIBLE":
                vehicle["status"] = "indisponible"
                vehicle["model"] = "❌ Non affecté"
            
            # Find nb tours
            df_pr_tours = df_tours[(df_tours["DHDEBPER"].astype(str).str.startswith(date_str)) & (df_tours["PARAPHE"] == pr)]
            stops = len(df_pr_tours)
            tourneeType = "Multiples"
            if stops > 0:
                tourneeType = str(df_pr_tours.iloc[0]["TYPE_TOURNEE"])
            
            status = "en cours" if date_obj == today else "planifié"
            if date_obj < today:
                status = "terminé"
            if veh == "AUCUN DISPONIBLE":
                status = "non assigné"
                
            assignments.append({
                "id": f"{date_str}-{pr}",
                "date": date_str,
                "dayName": day_name,
                "collector": collector,
                "vehicle": vehicle,
                "zone": collector["zone"],
                "tourneeType": contraintes if contraintes != "AUCUNE (TOUS TYPE)" else tourneeType,
                "startTime": "08:00",
                "endTime": "16:00",
                "stops": stops,
                "status": status
            })
            
        stats = {
            "totalCollectors": len(real_collectors),
            "activeCollectors": len(real_collectors),
            "totalVehicles": len(real_vehicles),
            "todayAssignments": len(df_resume[df_resume["DATE"].astype(str).str.startswith(str(today))]),
            "weekAssignments": len(df_resume),
            "unassignedTotal": len(df_resume[df_resume["VEHICULE_ASSIGNE"] == "AUCUN DISPONIBLE"])
        }
            
        return {"assignments": assignments, "stats": stats}
    except Exception as e:
        print(f"Error parsing Excel: {e}")
        return {"assignments": [], "stats": {}, "error": str(e)}

def export_attribution_csv_data() -> str:
    attr_path = os.path.join(DATA_DIR, "attribution_vehicules.xlsx")
    if not os.path.exists(attr_path):
        raise FileNotFoundError("Fichier d'attribution non trouvé.")
    df = pd.read_excel(attr_path, sheet_name="Attribution")
    return df.to_csv(index=False, sep=";", encoding="utf-8-sig")

def get_vehicles_maintenance_data() -> list:
    file_veh = os.path.join(DATA_DIR, "vehicules.xlsx")
    file_attr = os.path.join(DATA_DIR, "attribution_vehicules.xlsx")

    if not os.path.exists(file_veh) or not os.path.exists(file_attr):
        return []

    try:
        df_dispo = pd.read_excel(file_veh, sheet_name="Véhicules dispo")
        df_dispo.columns = df_dispo.columns.astype(str).str.replace(r'[\n\r]', ' ', regex=True).str.strip()
        df_dispo['Date'] = pd.to_datetime(df_dispo['Date'])
        
        col_immat = next((c for c in df_dispo.columns if "IMMATRICULATION" in c.upper()), None)
        if not col_immat:
            return []

        df_indispo = df_dispo[df_dispo['Disponibilité'].isin([0, False, "0", "false"])].copy()
        df_attr = pd.read_excel(file_attr, sheet_name="Attribution")
        df_attr['DHDEBPER'] = pd.to_datetime(df_attr['DHDEBPER'])
        results = []
        
        for plate, group in df_indispo.groupby(col_immat):
            group = group.sort_values(by='Date')
            dates = group['Date'].tolist()
            periods = []
            if dates:
                start_period = dates[0]
                current_date = dates[0]
                for d in dates[1:]:
                    if (d - current_date).days <= 3:
                        current_date = d
                    else:
                        periods.append((start_period, current_date))
                        start_period = d
                        current_date = d
                periods.append((start_period, current_date))
                
            periods_with_next = []
            for start, end in periods:
                upcoming = df_attr[(df_attr['VEHICULE_ASSIGNE'] == plate) & (df_attr['DHDEBPER'] > end)]
                upcoming = upcoming.sort_values(by='DHDEBPER')
                next_aff = None
                if not upcoming.empty:
                    first = upcoming.iloc[0]
                    next_aff = {
                        "date": first['DHDEBPER'].strftime('%d/%m/%Y'),
                        "tournee": str(first['TYPE_TOURNEE']),
                        "preleveur": str(first['PARAPHE'])
                    }
                periods_with_next.append({
                    "debut": start.strftime('%d/%m/%Y'),
                    "fin": end.strftime('%d/%m/%Y'),
                    "prochaine_affectation": next_aff
                })
            results.append({
                "plate": str(plate),
                "maintenances": periods_with_next
            })
        return results
    except Exception as e:
        return {"error": str(e)}

def get_vehicles_data() -> list:
    vehic_path = os.path.join(DATA_DIR, "vehicules.xlsx")
    if not os.path.exists(vehic_path):
        return []
        
    try:
        df_veh = pd.read_excel(vehic_path, sheet_name="préférence", skiprows=1)
        df_veh.columns = df_veh.columns.str.replace("[\n\r]", " ", regex=True).str.replace(r"\s+", " ", regex=True)
        
        status_map = {}
        try:
            df_dispo = pd.read_excel(vehic_path, sheet_name="Véhicules dispo")
            df_dispo.columns = df_dispo.columns.astype(str).str.replace(r'[\n\r]', ' ', regex=True).str.strip()
            col_immat = next((c for c in df_dispo.columns if "IMMATRICULATION" in c.upper()), None)
            if col_immat:
                df_dispo['Date'] = pd.to_datetime(df_dispo['Date'])
                df_dispo = df_dispo.sort_values(by='Date')
                for plate, group in df_dispo.groupby(col_immat):
                    if not group.empty:
                        last_row = group.iloc[-1]
                        is_ok = last_row.get("Disponibilité", 1)
                        if is_ok in [0, False, "0", "false"]:
                            status_map[str(plate)] = "maintenance"
                        else:
                            status_map[str(plate)] = "disponible"
        except Exception as ex:
            print(f"Non-critical: could not parse vehicle status: {ex}")

        vehicles = []
        for _, row in df_veh.iterrows():
            p = clean_nan(row.get("VEHICULE IMMATRICULATION", ""))
            if not p: continue
            vehicles.append({
                "id": p,
                "plate": p,
                "model": clean_nan(row.get("type de véhicule", "")),
                "collector_pref": clean_nan(row.get("Paraphe", "")),
                "type": clean_nan(row.get("type de véhicule", "")),
                "capacity": "N/A", 
                "fuelType": "Diesel",
                "status": status_map.get(str(p), "disponible")
            })
        return vehicles
    except Exception as e:
        print(f"Error reading vehicles: {e}")
        return []

def get_collectors_data() -> list:
    return list(load_real_collectors().values())
