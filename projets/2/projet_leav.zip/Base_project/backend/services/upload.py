"""
@purpose   : Service gérant la sauvegarde d'un fichier xlsx ET le recalcul d'attribution
@logic     : 1) save_xlsx → écrit le fichier dans _data/
             2) run_liaison(data_dir) → re-calcule les attributions véhicules/tournées
             La fonction retourne un tuple (file_path, liaison_result | None, error | None)
@decisions : run_liaison est appelé après chaque upload pour garantir que les données
             d'attribution sont toujours à jour. En cas d'échec, l'upload reste valide
             mais liaison_error indique le problème.
@references: https://fastapi.tiangolo.com/tutorial/request-files/
"""

import os
import shutil
from fastapi import UploadFile
from services.liaison import run_liaison


def save_xlsx(file: UploadFile, data_dir: str) -> tuple:
    """
    Sauvegarde le fichier xlsx dans data_dir, puis re-exécute liaison.
    @return: (file_path: str, liaison_result: dict | None, error: str | None)
    """
    os.makedirs(data_dir, exist_ok=True)
    file_path = os.path.join(data_dir, file.filename)

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # ---- Re-exécution de liaison après la sauvegarde ----
    try:
        result = run_liaison(data_dir)
        return file_path, result, None
    except Exception as exc:
        return file_path, None, str(exc)
