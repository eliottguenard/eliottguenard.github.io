"""
@purpose   : Service d'attribution des véhicules aux tournées (wrapping de _pandas/liaison.py)
             Expose une fonction `run_liaison(data_dir)` appelable après chaque upload de fichier.
@logic     : Chargement Excel depuis data_dir → normalisation → cross-join type tournée/véhicule
             → pré-calcul contraintes PR → algorithme d'attribution 1 PR = 1 véhicule/jour
             → export attribution_vehicules.xlsx dans data_dir
@decisions : Encapsuler la logique dans une fonction (et non un script) permet à l'API de
             l'appeler de manière synchrone et de capturer les erreurs sans crash du serveur.
             Le data_dir est paramétrable pour ne pas dépendre de chemins relatifs fragiles.
@references: https://pandas.pydata.org | https://docs.python.org/3/library/unicodedata.html
"""

import os
import pandas as pd
import numpy as np
import unicodedata
import re


# ============================================================
# Normalisation
# ============================================================

def _normalize(s):
    """
    @purpose  : Normaliser un texte de type véhicule pour comparaison homogène
    @logic    : Majuscules → suppression accents NFKD → nettoyage retours ligne
                → suppression caractères spéciaux (hors alphanum/espace)
                → espaces multiples → 1 seul → tokens stables sans espaces internes
    @decisions: Tokens SANS espace interne (2PLACES, 3PLACES, KANGOOR) pour éviter
                toute ambiguïté lors des tests `substring in string`.
    @references: https://docs.python.org/3/library/unicodedata.html
    """
    if pd.isna(s):
        return ""
    s = str(s).upper()
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("utf-8")
    s = re.sub(r"[\r\n\t]+", " ", s)
    s = re.sub(r"[^\w\s]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = s.replace("2 PLACES", "2PLACES")
    s = s.replace("3 PLACES", "3PLACES")
    s = s.replace("KANGOO R", "KANGOOR")
    return s


# ============================================================
# Compatibilité véhicule ↔ contrainte
# ============================================================

def _vehicule_compatible(required_norm: str, real_norm: str) -> bool:
    """
    @purpose  : Vérifier qu'un véhicule (real_norm) satisfait une contrainte (required_norm)
    @logic    : Tokens normalisés SANS espaces internes. On teste la présence de chaque
                sous-chaîne. KANGOOR testé avant KANGOO pour éviter les faux positifs.
    @decisions: "2PLACES" (2 places ou plus) accepte aussi les véhicules "3PLACES".
                Un véhicule doit satisfaire TOUTES les contraintes présentes.
    """
    if required_norm == "" or required_norm == "TOUSTYPE":
        return True

    R = required_norm
    V = real_norm

    if "ATTELAGE" in R and "ATTELAGE" not in V:
        return False

    if "KANGOOR" in R:
        if "KANGOOR" not in V:
            return False
    elif "KANGOO" in R:
        if "KANGOO" not in V:
            return False

    if "TRAFIC" in R and "TRAFIC" not in V:
        return False

    if "3PLACES" in R and "3PLACES" not in V:
        return False

    if "2PLACES" in R:
        if "2PLACES" not in V and "3PLACES" not in V:
            return False

    return True


# ============================================================
# Fonction principale
# ============================================================

def run_liaison(data_dir: str) -> dict:
    """
    @purpose  : Ré-exécuter l'algorithme d'attribution des véhicules aux tournées
    @logic    : Charge les 4 fichiers Excel depuis data_dir, applique la logique de
                liaison, exporte le résultat dans data_dir/attribution_vehicules.xlsx
    @decisions: Retourne un dict avec les statistiques plutôt que de print() pour
                permettre à l'API de les inclure dans la réponse JSON.
                En cas d'erreur, lève une exception avec un message clair.
    @references: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_excel.html
    @param data_dir: Chemin absolu du dossier contenant les fichiers Excel source
    @return: {"total": int, "attribues": int, "sans_vehicule": int, "output_path": str}
    """

    # ---- 1) Chargement des fichiers Excel ----
    files = [
        "indisponibilite.xlsx",
        "preleveurs_trimestriel (1).xlsx",
        "Tournee.xlsx",
        "vehicules.xlsx",
    ]

    dfs = {}
    for file in files:
        full_path = os.path.join(data_dir, file)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Fichier manquant dans _data : {file}")

        file_name_body = file.split(".")[0]
        xls = pd.ExcelFile(full_path)

        for sheet in xls.sheet_names:
            df_key = f"{file_name_body}_{sheet}"

            if file == "vehicules.xlsx" and sheet == "préférence":
                df = pd.read_excel(xls, sheet_name=sheet, skiprows=1)
            elif file == "vehicules.xlsx" and sheet == "Obligation des véhicules":
                df = pd.read_excel(xls, sheet_name=sheet, skiprows=1)
                df = df.iloc[:, 1:]
            else:
                df = pd.read_excel(xls, sheet_name=sheet)

            dfs[df_key] = df

    dfs.pop("Tournee_SQL", None)

    # ---- 2) Préparation des DataFrames ----
    df_obligation = dfs["vehicules_Obligation des véhicules"]
    df_vehic = df_obligation.iloc[:, :2].copy()
    df_vehic.columns = ["TYPE_TOURNEE_CODE", "VEHICULE"]
    df_vehic["TYPE_TOURNEE_CODE"] = (
        df_vehic["TYPE_TOURNEE_CODE"].fillna("").astype(str).str.strip().str.upper()
    )
    df_vehic["VEHICULE"] = df_vehic["VEHICULE"].fillna("").astype(str).str.strip()
    df_vehic = df_vehic.dropna(subset=["TYPE_TOURNEE_CODE"])
    df_vehic = df_vehic[df_vehic["TYPE_TOURNEE_CODE"] != ""]
    
    # Agrégation multi-contraintes au lieu de drop_duplicates
    df_vehic = (
        df_vehic.groupby("TYPE_TOURNEE_CODE")["VEHICULE"]
        .apply(lambda x: " ".join(x.dropna().astype(str)))
        .reset_index()
    )

    df_tournee = dfs["Tournee_Exporter la feuille de calcul"]
    df_tournee["TYPE_TOURNEE"] = (
        df_tournee["TYPE_TOURNEE"].fillna("").astype(str).str.upper()
    )

    # ---- 3) Cross-join : matcher TYPE_TOURNEE avec TYPE_TOURNEE_CODE ----
    df_tmp = (
        df_tournee.assign(key=1)
        .merge(df_vehic.assign(key=1), on="key")
        .drop(columns="key")
    )

    df_matches = df_tmp[
        df_tmp.apply(lambda r: r["TYPE_TOURNEE_CODE"] in r["TYPE_TOURNEE"], axis=1)
    ]

    # Agrégation multi-contraintes au lieu de drop_duplicates
    df_matches = (
        df_matches.groupby(["DHDEBPER", "DSTOURNEE", "TYPE_TOURNEE", "NMALPH2"])["VEHICULE"]
        .apply(lambda x: " ".join(x.dropna().astype(str)))
        .reset_index()
    )

    df_final = df_tournee.merge(
        df_matches[["DHDEBPER", "DSTOURNEE", "TYPE_TOURNEE", "NMALPH2", "VEHICULE"]],
        on=["DHDEBPER", "DSTOURNEE", "TYPE_TOURNEE", "NMALPH2"],
        how="left",
    )
    df_final["VEHICULE"] = df_final["VEHICULE"].fillna("Tous type")

    # ---- 4) Préparation véhicules réels et disponibilités ----
    df_veh_reel = dfs["vehicules_préférence"].copy()
    df_dispo = dfs["vehicules_Véhicules dispo"].copy()

    df_veh_reel.columns = (
        df_veh_reel.columns
        .str.replace("\n", " ", regex=True)
        .str.replace("\r", " ", regex=True)
        .str.replace("  ", " ", regex=True)
    )
    df_veh_reel = df_veh_reel.rename(
        columns={"VEHICULE IMMATRICULATION": "IMMATRICULATION"}
    )

    df_veh = df_veh_reel.copy()
    df_veh["type de véhicule"] = (
        df_veh["type de véhicule"].fillna("").astype(str).str.upper()
    )
    df_veh["Paraphe"] = df_veh["Paraphe"].fillna("").astype(str).str.upper()

    df_dispo["Date"] = pd.to_datetime(df_dispo["Date"]).dt.normalize()
    df_dispo_ok = df_dispo[df_dispo["Disponibilité"] == 1].copy()
    df_dispo_ok.columns = df_dispo_ok.columns.str.replace("\n", " ", regex=True)
    df_dispo_ok = df_dispo_ok.rename(
        columns={"VEHICULE IMMATRICULATION": "IMMATRICULATION"}
    )

    # ---- 5) Normalisation ----
    df_final["PARAPHE"] = df_final["NMALPH2"].str.upper()
    df_final["TYPE_OBLIG_NORM"] = df_final["VEHICULE"].apply(_normalize)
    df_veh["TYPE_NORM"] = df_veh["type de véhicule"].apply(_normalize)

    # ---- 6) Tri par priorité ----
    df_final["PRIORITE_VEHICULE"] = df_final["TYPE_OBLIG_NORM"].apply(
        lambda s: 1 if s in ["", "TOUSTYPE", "TOUS TYPE"] else 0
    )
    df_final = df_final.sort_values(
        by=["DHDEBPER", "PRIORITE_VEHICULE", "PARAPHE"]
    ).reset_index(drop=True)
    df_final["VEHICULE_ASSIGNE"] = None

    # ---- 7) Pré-calcul contraintes unifiées par (Date, PR) ----
    df_final["_date_val"] = pd.to_datetime(df_final["DHDEBPER"]).dt.date

    pr_combined = (
        df_final.groupby(["_date_val", "PARAPHE"])["TYPE_OBLIG_NORM"]
        .apply(lambda lst: " ".join(sorted(set(
            word for s in lst if s not in ["", "TOUSTYPE", "TOUS TYPE"] for word in s.split()
        ))))
        .to_dict()
    )

    # ---- 8) Algorithme d'attribution : 1 PR = 1 véhicule / jour ----
    used = {}
    used_by_pr = {}

    for idx, row in df_final.iterrows():
        date_val = row["_date_val"]
        preleveur = row["PARAPHE"]

        used.setdefault(date_val, set())
        pr_key = (date_val, preleveur)

        if pr_key in used_by_pr:
            df_final.at[idx, "VEHICULE_ASSIGNE"] = used_by_pr[pr_key]
            continue

        combined_required = pr_combined.get(pr_key, "")
        effective_required = combined_required if combined_required else row["TYPE_OBLIG_NORM"]

        candidates = df_veh[
            df_veh.apply(
                lambda r: _vehicule_compatible(effective_required, r["TYPE_NORM"]),
                axis=1,
            )
        ].copy()

        dispo_today = df_dispo_ok[df_dispo_ok["Date"] == pd.Timestamp(date_val)]
        candidates = candidates[
            candidates["IMMATRICULATION"].isin(dispo_today["IMMATRICULATION"])
        ]

        candidates = candidates[
            ~candidates["IMMATRICULATION"].isin(used[date_val])
        ]

        candidates = candidates.sort_values(
            by="Paraphe",
            key=lambda s: (s != preleveur).astype(int),
        )

        if len(candidates) > 0:
            veh = candidates.iloc[0]["IMMATRICULATION"]
            df_final.at[idx, "VEHICULE_ASSIGNE"] = veh
            used[date_val].add(veh)
            used_by_pr[pr_key] = veh
        else:
            df_final.at[idx, "VEHICULE_ASSIGNE"] = "AUCUN DISPONIBLE"
            used_by_pr[pr_key] = "AUCUN DISPONIBLE"

    df_final.drop(columns=["_date_val"], inplace=True)

    # ---- 9) Export ----
    cols_export = [
        "DHDEBPER", "PARAPHE", "DSTOURNEE", "TYPE_TOURNEE",
        "VEHICULE", "TYPE_OBLIG_NORM", "PRIORITE_VEHICULE", "VEHICULE_ASSIGNE",
    ]
    cols_export = [c for c in cols_export if c in df_final.columns]

    output_path = os.path.join(data_dir, "attribution_vehicules.xlsx")

    # Création du résumé 1 ligne par PR et par jour
    resume_records = []
    for (d, pr), veh in used_by_pr.items():
        contraintes = pr_combined.get((d, pr), "")
        resume_records.append({
            "DATE": d,
            "PRELEVEUR": pr,
            "CONTRAINTES_JOURNEE": contraintes if contraintes else "AUCUNE (TOUS TYPE)",
            "VEHICULE_ASSIGNE": veh
        })
    df_resume = pd.DataFrame(resume_records)
    if not df_resume.empty:
        df_resume = df_resume.sort_values(by=["DATE", "PRELEVEUR"])

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df_final[cols_export].to_excel(
            writer, sheet_name="Attribution", index=False
        )
        if not df_resume.empty:
            df_resume.to_excel(
                writer, sheet_name="Résumé Quotidien", index=False
            )
            
        # Ajout de l'onglet indisponibilité (Feuil 1) en 3ème position
        df_indispo = dfs.get("indisponibilite_Feuil 1")
        if df_indispo is not None:
            df_indispo.to_excel(
                writer, sheet_name="Indisponibilité", index=False
            )
        stats_data = {
            "Statistique": [
                "Total tournées",
                "Attributions réussies",
                "Sans véhicule disponible",
                "Véhicules uniques utilisés",
            ],
            "Valeur": [
                len(df_final),
                int((df_final["VEHICULE_ASSIGNE"] != "AUCUN DISPONIBLE").sum()),
                int((df_final["VEHICULE_ASSIGNE"] == "AUCUN DISPONIBLE").sum()),
                int(
                    df_final[df_final["VEHICULE_ASSIGNE"] != "AUCUN DISPONIBLE"][
                        "VEHICULE_ASSIGNE"
                    ].nunique()
                ),
            ],
        }
        pd.DataFrame(stats_data).to_excel(
            writer, sheet_name="Statistiques", index=False
        )

    # ---- 10) Retour des statistiques ----
    total = len(df_final)
    sans_vehicule = int((df_final["VEHICULE_ASSIGNE"] == "AUCUN DISPONIBLE").sum())
    attribues = total - sans_vehicule

    return {
        "total": total,
        "attribues": attribues,
        "sans_vehicule": sans_vehicule,
        "output_path": output_path,
    }
