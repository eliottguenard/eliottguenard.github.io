import os
import pandas as pd
import oracledb
from datetime import datetime
from typing import Optional


class OracleConnectionError(Exception):
    """Custom exception for Oracle connection errors"""
    pass


class OracleQueryError(Exception):
    """Custom exception for Oracle query execution errors"""
    pass


class OracleExportError(Exception):
    """Custom exception for Oracle export errors"""
    pass


def get_oracle_connection_string() -> str:
    """
    Build Oracle connection string from environment variables.
    Format: user/password@host:port/service_name or user/password@host:port/SID
    """
    user = os.getenv("ORACLE_USER")
    password = os.getenv("ORACLE_PASSWORD")
    host = os.getenv("ORACLE_HOST")
    port = os.getenv("ORACLE_PORT", "1521")
    service = os.getenv("ORACLE_SERVICE", "ORCL")
    
    if not all([user, password, host]):
        raise OracleConnectionError(
            "Missing required Oracle connection parameters. "
            "Please set ORACLE_USER, ORACLE_PASSWORD, and ORACLE_HOST environment variables."
        )
    
    return f"{user}/{password}@{host}:{port}/{service}"


def test_connection() -> str:
    """
    Test Oracle database connection by attempting to connect and immediately close.
    Returns status string or raises OracleConnectionError.
    """
    connection = None
    try:
        dsn = get_oracle_connection_string()
        connection = oracledb.connect(dsn)
        return "Connexion réussie à la base de données Oracle."
    except oracledb.DatabaseError as e:
        raise OracleConnectionError(f"Échec de connexion Oracle : {str(e)}")
    except Exception as e:
        raise OracleConnectionError(f"Erreur inattendue : {str(e)}")
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass


def execute_query_to_dataframe(sql_query: str) -> pd.DataFrame:
    """
    Execute SQL query on Oracle database and return results as DataFrame.
    
    Args:
        sql_query: SQL query to execute
        
    Returns:
        pandas DataFrame with query results
        
    Raises:
        OracleConnectionError: If connection to Oracle fails
        OracleQueryError: If SQL execution fails
    """
    connection = None
    try:
        # Get connection string from environment variables
        dsn = get_oracle_connection_string()
        
        # Connect to Oracle database
        connection = oracledb.connect(dsn)
        
        # Execute query and load into DataFrame
        df = pd.read_sql(sql_query, connection)
        
        return df
        
    except oracledb.DatabaseError as e:
        error_msg = str(e)
        if "ORA-" in error_msg or "DPI-" in error_msg:
            raise OracleConnectionError(f"Oracle connection failed: {error_msg}")
        else:
            raise OracleQueryError(f"SQL execution failed: {error_msg}")
    except Exception as e:
        raise OracleQueryError(f"Unexpected error during query execution: {str(e)}")
    finally:
        # Always close the connection
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass  # Ignore errors during close


def export_to_excel(df: pd.DataFrame, filename: str, exports_dir: str = "/app/_data") -> str:
    """
    Export DataFrame to Excel file in the exports directory.
    
    Args:
        df: pandas DataFrame to export
        filename: Name of the output Excel file
        exports_dir: Directory to save the Excel file
        
    Returns:
        Full path to the created Excel file
        
    Raises:
        OracleExportError: If file creation fails
    """
    connection = None
    try:
        # Create exports directory if it doesn't exist
        os.makedirs(exports_dir, exist_ok=True)
        
        # Build file path
        file_path = os.path.join(exports_dir, filename)
        
        # Export DataFrame to Excel
        df.to_excel(file_path, index=False, engine='openpyxl')
        
        return file_path
        
    except PermissionError as e:
        raise OracleExportError(f"Permission denied when creating file: {str(e)}")
    except OSError as e:
        raise OracleExportError(f"File system error: {str(e)}")
    except Exception as e:
        raise OracleExportError(f"Unexpected error during Excel export: {str(e)}")


def execute_and_export(sql_query: str, filename: str, exports_dir: str = "/app/_data") -> dict:
    """
    Execute SQL query on Oracle and export results to Excel file.
    
    Args:
        sql_query: SQL query to execute
        filename: Name of the output Excel file
        exports_dir: Directory to save the Excel file
        
    Returns:
        Dictionary with status and file path
    """
    # Execute query and get DataFrame
    df = execute_query_to_dataframe(sql_query)
    
    # Export to Excel
    file_path = export_to_excel(df, filename, exports_dir)
    
    return {
        "status": "success",
        "rows": len(df),
        "columns": len(df.columns),
        "filename": filename,
        "file_path": file_path,
        "exported_at": datetime.now().isoformat()
    }


def execute_tournee_query(
    cdgrpe: str,
    dhdebper: str,
    dhfinper: str,
    filename: str = "tournee_export.xlsx",
    exports_dir: str = "/app/_data"
) -> dict:
    """
    Execute the tourneé query with parameters and export results to Excel.
    
    Args:
        cdgrpe: Code groupe (e.g., 'PR')
        dhdebper: Date début période (format: 'DD/MM/YY')
        dhfinper: Date fin période (format: 'DD/MM/YY')
        filename: Name of the output Excel file
        exports_dir: Directory to save the Excel file
        
    Returns:
        Dictionary with status and file path
    """
    sql_query = f"""
        SELECT DISTINCT 
            DHDEBPER,
            DSTOURNEE,
            nvl(trim(trim(CDMODTRN)||' '||TTINFPRLV),'Non Renseigné') type_tournee,
            NMALPH2 
        FROM ARTOURNEE TOURN
        INNER JOIN TITIER 
            ON TOURN.CDGRPE=TITIER.CDGRPE 
            AND TOURN.NOTIER=TITIER.NOTIER 
            AND TOURN.CDEQDOS=TITIER.CDEQDOS
        INNER JOIN ARINTERV
            ON ARINTERV.IDTOURNEE=TOURN.IDTOURNEE
        WHERE TITIER.CDGRPE='{cdgrpe}'
            AND DHDEBPER>='{dhdebper}' 
            AND DHFINPER<='{dhfinper}'
        ORDER BY DHDEBPER
    """
    
    # Execute query and get DataFrame
    df = execute_query_to_dataframe(sql_query)
    
    # Export to Excel
    file_path = export_to_excel(df, filename, exports_dir)
    
    return {
        "status": "success",
        "rows": len(df),
        "columns": len(df.columns),
        "filename": filename,
        "file_path": file_path,
        "exported_at": datetime.now().isoformat()
    }
