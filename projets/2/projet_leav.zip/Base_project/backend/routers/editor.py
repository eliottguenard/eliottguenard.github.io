"""
@AI_SPACE
@purpose   : Router pour l'édition manuelle des différents fichiers Excel vitaux
@logic     : Intercepte les requêtes HTTP de l'éditeur React, valide le Payload via Pydantic, et délègue l'exécution à `services.editor`
@decisions : Code épuré de toute logique métier (conformité séparation des couches)
@references: https://fastapi.tiangolo.com/tutorial/routing/
"""
from fastapi import APIRouter, HTTPException
from models.editor import UpdateDataRequest
from services.editor import read_editor_data, write_editor_data, EditorFileError, EditorReadError

router = APIRouter(prefix="/editor", tags=["editor"])

@router.get("/{file_key}")
async def get_editor_data(file_key: str):
    try:
        return read_editor_data(file_key)
    except EditorFileError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except EditorReadError as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{file_key}")
async def update_editor_data(file_key: str, req: UpdateDataRequest):
    try:
        return write_editor_data(file_key, req.data)
    except EditorFileError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except EditorReadError as e:
        raise HTTPException(status_code=500, detail=str(e))
