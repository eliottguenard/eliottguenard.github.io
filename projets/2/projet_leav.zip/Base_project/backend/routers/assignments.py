"""
@AI_SPACE
@purpose   : Routeur HTTP pour exposer l'état des affectations, véhicules et préleveurs.
@logic     : Intercepte les requêtes GET et renvoie les données construites par le service métier.
@decisions : Code minimaliste, aucune manipulation Excel ou Pandas directement dans le routeur.
@references: https://fastapi.tiangolo.com/
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response, FileResponse
import os

from models.assignments import AssignmentsResponse, Vehicle, Collector
from services.assignments import (
    get_assignments_data,
    export_attribution_csv_data,
    get_vehicles_maintenance_data,
    get_vehicles_data,
    get_collectors_data
)

router = APIRouter()

@router.get("/assignments", response_model=AssignmentsResponse)
async def get_assignments():
    return get_assignments_data()

@router.get("/export/xlsx")
async def export_attribution_xlsx():
    """
    Exporte le fichier complet 'attribution_vehicules.xlsx' contenant tous les onglets.
    """
    from services.assignments import DATA_DIR
    attr_path = os.path.join(DATA_DIR, "attribution_vehicules.xlsx")
    if not os.path.exists(attr_path):
        raise HTTPException(status_code=404, detail="Fichier d'attribution non trouvé.")
    return FileResponse(
        path=attr_path,
        filename="attribution_vehicules.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@router.get("/vehicles/maintenance")
async def get_vehicles_maintenance():
    rv = get_vehicles_maintenance_data()
    if isinstance(rv, dict) and "error" in rv:
        raise HTTPException(status_code=500, detail=rv["error"])
    return rv

@router.get("/vehicles")
async def get_vehicles():
    return get_vehicles_data()

@router.get("/collectors")
async def get_collectors():
    return get_collectors_data()
