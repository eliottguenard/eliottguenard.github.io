import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import './Header.css'

export default function Header() {
  const location = useLocation()
  const today = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })

  const navItems = [
    { path: '/', label: 'Tableau de bord', icon: '📊' },
    { path: '/planning', label: 'Planning', icon: '📅' },
    { path: '/preleveurs', label: 'Préleveurs', icon: '👥' },
    { path: '/vehicules', label: 'Véhicules', icon: '🚗' },
  ]

  return (
    <header className="header">
      <div className="header__left">
        <div className="header__logo">
          <div className="header__logo-icon">L</div>
          <div className="header__logo-text">
            <span className="header__logo-title">LEAV</span>
            <span className="header__logo-subtitle">Gestion des Tournées</span>
          </div>
        </div>

        <nav className="header__nav">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `header__nav-link ${isActive ? 'active' : ''}`
              }
              end={item.path === '/'}
            >
              <span className="header__nav-icon">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="header__right">
      </div>
    </header>
  )
}
