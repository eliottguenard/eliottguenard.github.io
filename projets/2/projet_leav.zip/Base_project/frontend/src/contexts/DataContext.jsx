import React, { createContext, useContext, useState, useEffect } from 'react';

const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [data, setData] = useState({
    assignments: [],
    stats: {},
    collectors: [],
    vehicles: [],
    zones: ['Nord Vendée', 'Sud Vendée', 'Est Vendée', 'Littoral', 'Centre Vendée']
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentViewDate, setCurrentViewDate] = useState(new Date());


  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        // On récupère les 3 endpoints
        const [assigRes, vehicRes, collRes] = await Promise.all([
          fetch('http://localhost:8000/api/assignments'),
          fetch('http://localhost:8000/api/vehicles'),
          fetch('http://localhost:8000/api/collectors')
        ]);
        
        if (!assigRes.ok) throw new Error("Erreur réseau requêtes JSON");
        
        const assigData = await assigRes.json();
        const vehicles = await vehicRes.json();
        const collectors = await collRes.json();

        setData(prev => ({
          ...prev,
          assignments: assigData.assignments || [],
          stats: assigData.stats || {},
          vehicles: vehicles || [],
          collectors: collectors || []
        }));

        // Ancrage temporel : on cherche la date max des affectations
        if (assigData.assignments && assigData.assignments.length > 0) {
          const dates = assigData.assignments
            .map(a => a.date)
            .filter(Boolean)
            .map(d => new Date(d));
          if (dates.length > 0) {
            const maxDate = new Date(Math.max.apply(null, dates));
            setCurrentViewDate(maxDate);
          }
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Recréation des utilitaires liés aux dates
  const today = new Date();
  
  function getDateStr(offset) {
    const d = new Date(currentViewDate);
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
  }

  function getDayName(offset) {
    const d = new Date(currentViewDate);
    d.setDate(d.getDate() + offset);
    return d.toLocaleDateString('fr-FR', { weekday: 'long' });
  }

  const helpers = {
    getAssignmentsByDate: (date) => data.assignments.filter(a => a.date === date),
    getAssignmentsByCollector: (collectorId) => data.assignments.filter(a => String(a.collector.id) === String(collectorId)),
    getAssignmentsByVehicle: (vehicleId) => data.assignments.filter(a => String(a.vehicle.id) === String(vehicleId)),
    getTodayAssignments: () => data.assignments.filter(a => a.date === getDateStr(0)),
    changeWeek: (days) => {
      setCurrentViewDate(prev => {
        const next = new Date(prev);
        next.setDate(next.getDate() + days);
        return next;
      });
    },
    setViewDate: (dateStr) => {
      setCurrentViewDate(new Date(dateStr));
    },
    getWeekDates: () => {
      const dates = [];
      const d = new Date(currentViewDate);
      const dayOfWeek = d.getDay(); // 0 is Sunday, 1 is Monday
      
      // Calcul du lundi de cette semaine
      const offsetToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
      d.setDate(d.getDate() + offsetToMonday);

      // Boucle sur 7 jours (Lundi à Dimanche)
      for (let i = 0; i < 7; i++) {
        const current = new Date(d);
        current.setDate(d.getDate() + i);
        
        const year = current.getFullYear();
        const month = String(current.getMonth() + 1).padStart(2, '0');
        const day = String(current.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;

        dates.push({
          date: dateStr,
          dayName: current.toLocaleDateString('fr-FR', { weekday: 'long' }),
          dayNumber: current.getDate(),
          monthName: current.toLocaleDateString('fr-FR', { month: 'short' }),
          year: current.getFullYear(),
          isToday: current.toDateString() === new Date().toDateString(),
        });
      }
      return dates;
    }
  };

  return (
    <DataContext.Provider value={{ ...data, ...helpers, currentViewDate, loading, error }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData hook calls must be used within DataProvider');
  }
  return context;
}
