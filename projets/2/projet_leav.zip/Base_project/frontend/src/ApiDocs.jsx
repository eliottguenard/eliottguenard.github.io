import React, { useState } from 'react'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

// Style CSS inline
const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    fontFamily: 'Arial, sans-serif'
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px',
    color: '#333'
  },
  section: {
    marginBottom: '30px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '20px',
    backgroundColor: '#f9f9f9'
  },
  sectionTitle: {
    color: '#1976d2',
    borderBottom: '2px solid #1976d2',
    paddingBottom: '10px',
    marginBottom: '15px'
  },
  endpoint: {
    marginBottom: '25px',
    padding: '15px',
    backgroundColor: '#fff',
    borderRadius: '8px',
    border: '1px solid #e0e0e0'
  },
  method: {
    display: 'inline-block',
    padding: '4px 12px',
    borderRadius: '4px',
    fontWeight: 'bold',
    fontSize: '14px',
    marginRight: '10px'
  },
  methodGet: { backgroundColor: '#61affe', color: '#fff' },
  methodPost: { backgroundColor: '#49cc90', color: '#fff' },
  methodPut: { backgroundColor: '#fca130', color: '#fff' },
  methodDelete: { backgroundColor: '#f93e3e', color: '#fff' },
  path: {
    fontFamily: 'monospace',
    fontSize: '16px',
    color: '#333'
  },
  description: {
    color: '#666',
    marginTop: '10px',
    marginBottom: '15px'
  },
  param: {
    marginBottom: '10px'
  },
  label: {
    display: 'block',
    fontWeight: 'bold',
    marginBottom: '5px',
    color: '#444'
  },
  input: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '14px',
    fontFamily: 'monospace'
  },
  textarea: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '14px',
    fontFamily: 'monospace',
    minHeight: '80px'
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#1976d2',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    marginTop: '10px'
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
    cursor: 'not-allowed'
  },
  response: {
    marginTop: '15px',
    padding: '15px',
    backgroundColor: '#1e1e1e',
    borderRadius: '4px',
    overflow: 'auto'
  },
  responseTitle: {
    color: '#aaa',
    fontSize: '12px',
    marginBottom: '10px'
  },
  pre: {
    color: '#d4d4d4',
    fontSize: '13px',
    fontFamily: 'monospace',
    margin: 0,
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-all'
  },
  fileInput: {
    marginTop: '5px'
  },
  nav: {
    display: 'flex',
    gap: '10px',
    marginBottom: '20px',
    flexWrap: 'wrap'
  },
  navButton: {
    padding: '8px 16px',
    backgroundColor: '#f0f0f0',
    border: '1px solid #ddd',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  navButtonActive: {
    backgroundColor: '#1976d2',
    color: '#fff',
    border: '1px solid #1976d2'
  },
  tabs: {
    display: 'flex',
    borderBottom: '2px solid #ddd',
    marginBottom: '20px'
  },
  tab: {
    padding: '10px 20px',
    cursor: 'pointer',
    borderBottom: '2px solid transparent',
    marginBottom: '-2px'
  },
  tabActive: {
    borderBottom: '2px solid #1976d2',
    color: '#1976d2',
    fontWeight: 'bold'
  },
  paramTable: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '10px'
  },
  paramTh: {
    textAlign: 'left',
    padding: '8px',
    borderBottom: '2px solid #ddd',
    backgroundColor: '#f5f5f5'
  },
  paramTd: {
    padding: '8px',
    borderBottom: '1px solid #eee'
  },
  required: {
    color: '#f44336',
    fontSize: '12px'
  }
}

// Composant pour chaque endpoint
function EndpointCard({ method, path, description, params, children }) {
  const methodStyles = {
    GET: styles.methodGet,
    POST: styles.methodPost,
    PUT: styles.methodPut,
    DELETE: styles.methodDelete
  }

  return (
    <div style={styles.endpoint}>
      <div>
        <span style={{ ...styles.method, ...methodStyles[method] }}>{method}</span>
        <span style={styles.path}>{path}</span>
      </div>
      <p style={styles.description}>{description}</p>
      {params && params.length > 0 && (
        <table style={styles.paramTable}>
          <thead>
            <tr>
              <th style={styles.paramTh}>Paramètre</th>
              <th style={styles.paramTh}>Type</th>
              <th style={styles.paramTh}>Description</th>
            </tr>
          </thead>
          <tbody>
            {params.map((param, idx) => (
              <tr key={idx}>
                <td style={styles.paramTd}>
                  {param.name}
                  {param.required && <span style={styles.required}> *</span>}
                </td>
                <td style={styles.paramTd}><code>{param.type}</code></td>
                <td style={styles.paramTd}>{param.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {children}
    </div>
  )
}

// Page principale
export default function ApiDocs() {
  const [activeTab, setActiveTab] = useState('oracle')

  // États pour chaque endpoint
  const [rootResponse, setRootResponse] = useState(null)
  const [summaryResponse, setSummaryResponse] = useState(null)
  
  // Upload
  const [uploadFile, setUploadFile] = useState(null)
  const [uploadResponse, setUploadResponse] = useState(null)
  const [uploadLoading, setUploadLoading] = useState(false)
  
  // Oracle Export
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM ARTOURNEE WHERE ROWNUM <= 10')
  const [exportFilename, setExportFilename] = useState('test_export.xlsx')
  const [exportResponse, setExportResponse] = useState(null)
  const [exportLoading, setExportLoading] = useState(false)
  
  // Tournee Export
  const [cdgrpe, setCdgrpe] = useState('PR')
  const [dhdebper, setDhdebper] = useState('01/10/25')
  const [dhfinper, setDhfinper] = useState('01/01/26')
  const [tourneeFilename, setTourneeFilename] = useState('tournee_export.xlsx')
  const [tourneeResponse, setTourneeResponse] = useState(null)
  const [tourneeLoading, setTourneeLoading] = useState(false)
  
  // Connection Test
  const [connectionResponse, setConnectionResponse] = useState(null)
  const [connectionLoading, setConnectionLoading] = useState(false)
  
  // Exports List
  const [exportsListResponse, setExportsListResponse] = useState(null)
  const [exportsListLoading, setExportsListLoading] = useState(false)
  
  // Download
  const [downloadFilename, setDownloadFilename] = useState('')
  const [downloadResponse, setDownloadResponse] = useState(null)
  const [downloadLoading, setDownloadLoading] = useState(false)

  // Fonctions API
  const testRoot = async () => {
    try {
      const res = await fetch(`${API_BASE}/`)
      const data = await res.json()
      setRootResponse({ status: res.status, data })
    } catch (e) {
      setRootResponse({ error: e.message })
    }
  }

  const testSummary = async () => {
    try {
      const res = await fetch(`${API_BASE}/data/summary`)
      const data = await res.json()
      setSummaryResponse({ status: res.status, data })
    } catch (e) {
      setSummaryResponse({ error: e.message })
    }
  }

  const testUpload = async () => {
    if (!uploadFile) return
    setUploadLoading(true)
    const formData = new FormData()
    formData.append('file', uploadFile)
    try {
      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        body: formData
      })
      const data = await res.json()
      setUploadResponse({ status: res.status, data })
    } catch (e) {
      setUploadResponse({ error: e.message })
    }
    setUploadLoading(false)
  }

  const testExportOracle = async () => {
    setExportLoading(true)
    try {
      const res = await fetch(`${API_BASE}/oracle/export_oracle_xlsx`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql_query: sqlQuery, filename: exportFilename })
      })
      const data = await res.json()
      setExportResponse({ status: res.status, data })
    } catch (e) {
      setExportResponse({ error: e.message })
    }
    setExportLoading(false)
  }

  const testExportTournee = async () => {
    setTourneeLoading(true)
    try {
      const res = await fetch(`${API_BASE}/oracle/export_tournee`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          cdgrpe, 
          dhdebper, 
          dhfinper, 
          filename: tourneeFilename 
        })
      })
      const data = await res.json()
      setTourneeResponse({ status: res.status, data })
    } catch (e) {
      setTourneeResponse({ error: e.message })
    }
    setTourneeLoading(false)
  }

  const testConnection = async () => {
    setConnectionLoading(true)
    try {
      const res = await fetch(`${API_BASE}/oracle/test_connection`)
      const data = await res.json()
      setConnectionResponse({ status: res.status, data })
    } catch (e) {
      setConnectionResponse({ error: e.message })
    }
    setConnectionLoading(false)
  }

  const testExportsList = async () => {
    setExportsListLoading(true)
    try {
      const res = await fetch(`${API_BASE}/oracle/exports_list`)
      const data = await res.json()
      setExportsListResponse({ status: res.status, data })
    } catch (e) {
      setExportsListResponse({ error: e.message })
    }
    setExportsListLoading(false)
  }

  const testDownload = async () => {
    if (!downloadFilename) return
    setDownloadLoading(true)
    try {
      const res = await fetch(`${API_BASE}/oracle/download_oracle_export/${downloadFilename}`)
      if (res.ok) {
        const blob = await res.blob()
        setDownloadResponse({ 
          status: res.status, 
          data: `Fichier téléchargé: ${blob.size} bytes, type: ${blob.type}` 
        })
      } else {
        const data = await res.json()
        setDownloadResponse({ status: res.status, data })
      }
    } catch (e) {
      setDownloadResponse({ error: e.message })
    }
    setDownloadLoading(false)
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>📚 API Documentation & Testing</h1>
      
      {/* Navigation par catégorie */}
      <div style={styles.nav}>
        <button 
          style={{ ...styles.navButton, ...(activeTab === 'general' ? styles.navButtonActive : {}) }}
          onClick={() => setActiveTab('general')}
        >
          🏠 General
        </button>
        <button 
          style={{ ...styles.navButton, ...(activeTab === 'upload' ? styles.navButtonActive : {}) }}
          onClick={() => setActiveTab('upload')}
        >
          📤 Upload
        </button>
        <button 
          style={{ ...styles.navButton, ...(activeTab === 'oracle' ? styles.navButtonActive : {}) }}
          onClick={() => setActiveTab('oracle')}
        >
          🗄️ Oracle
        </button>
      </div>

      {/* ===== SECTION GENERAL ===== */}
      {activeTab === 'general' && (
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Endpoints Généraux</h2>
          
          <EndpointCard 
            method="GET" 
            path="/" 
            description="Endpoint racine - Retourne un message de bienvenue"
            params={[]}
          >
            <button style={styles.button} onClick={testRoot}>Tester</button>
            {rootResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(rootResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

          <EndpointCard 
            method="GET" 
            path="/data/summary" 
            description="Retourne un résumé statistiques (exemple avec pandas)"
            params={[]}
          >
            <button style={styles.button} onClick={testSummary}>Tester</button>
            {summaryResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(summaryResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>
        </div>
      )}

      {/* ===== SECTION UPLOAD ===== */}
      {activeTab === 'upload' && (
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Endpoints Upload</h2>
          
          <EndpointCard 
            method="POST" 
            path="/upload" 
            description="Upload un fichier Excel (.xlsx) vers le serveur"
            params={[
              { name: 'file', type: 'File', description: 'Fichier Excel à uploader', required: true }
            ]}
          >
            <div style={styles.param}>
              <label style={styles.label}>Fichier:</label>
              <input 
                type="file" 
                accept=".xlsx" 
                style={styles.fileInput}
                onChange={(e) => setUploadFile(e.target.files[0])}
              />
            </div>
            <button 
              style={{ ...styles.button, ...(uploadLoading || !uploadFile ? styles.buttonDisabled : {}) }}
              onClick={testUpload}
              disabled={uploadLoading || !uploadFile}
            >
              {uploadLoading ? 'Chargement...' : 'Uploader'}
            </button>
            {uploadResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(uploadResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>
        </div>
      )}

      {/* ===== SECTION ORACLE ===== */}
      {activeTab === 'oracle' && (
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Endpoints Oracle</h2>

          <EndpointCard 
            method="POST" 
            path="/oracle/export_oracle_xlsx" 
            description="Exécute une requête SQL sur Oracle et exporte les résultats en Excel"
            params={[
              { name: 'sql_query', type: 'string', description: 'Requête SQL à exécuter', required: true },
              { name: 'filename', type: 'string', description: 'Nom du fichier de sortie (défaut: oracle_export.xlsx)', required: false }
            ]}
          >
            <div style={styles.param}>
              <label style={styles.label}>SQL Query:</label>
              <textarea 
                style={styles.textarea}
                value={sqlQuery}
                onChange={(e) => setSqlQuery(e.target.value)}
              />
            </div>
            <div style={styles.param}>
              <label style={styles.label}>Filename:</label>
              <input 
                type="text" 
                style={styles.input}
                value={exportFilename}
                onChange={(e) => setExportFilename(e.target.value)}
              />
            </div>
            <button 
              style={{ ...styles.button, ...(exportLoading ? styles.buttonDisabled : {}) }}
              onClick={testExportOracle}
              disabled={exportLoading}
            >
              {exportLoading ? 'Export en cours...' : 'Exporter'}
            </button>
            {exportResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(exportResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

          <EndpointCard 
            method="POST" 
            path="/oracle/export_tournee" 
            description="Exporte les données de tournée Oracle avec paramètres"
            params={[
              { name: 'cdgrpe', type: 'string', description: 'Code groupe (défaut: PR)', required: false },
              { name: 'dhdebper', type: 'string', description: 'Date début période format DD/MM/YY (défaut: 01/10/25)', required: false },
              { name: 'dhfinper', type: 'string', description: 'Date fin période format DD/MM/YY (défaut: 01/01/26)', required: false },
              { name: 'filename', type: 'string', description: 'Nom du fichier de sortie (défaut: tournee_export.xlsx)', required: false }
            ]}
          >
            <div style={styles.param}>
              <label style={styles.label}>cdgrpe (Code groupe):</label>
              <input 
                type="text" 
                style={styles.input}
                value={cdgrpe}
                onChange={(e) => setCdgrpe(e.target.value)}
              />
            </div>
            <div style={styles.param}>
              <label style={styles.label}>dhdebper (Date début):</label>
              <input 
                type="text" 
                style={styles.input}
                value={dhdebper}
                onChange={(e) => setDhdebper(e.target.value)}
              />
            </div>
            <div style={styles.param}>
              <label style={styles.label}>dhfinper (Date fin):</label>
              <input 
                type="text" 
                style={styles.input}
                value={dhfinper}
                onChange={(e) => setDhfinper(e.target.value)}
              />
            </div>
            <div style={styles.param}>
              <label style={styles.label}>Filename:</label>
              <input 
                type="text" 
                style={styles.input}
                value={tourneeFilename}
                onChange={(e) => setTourneeFilename(e.target.value)}
              />
            </div>
            <button 
              style={{ ...styles.button, ...(tourneeLoading ? styles.buttonDisabled : {}) }}
              onClick={testExportTournee}
              disabled={tourneeLoading}
            >
              {tourneeLoading ? 'Export en cours...' : 'Exporter Tournée'}
            </button>
            {tourneeResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(tourneeResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

          <EndpointCard 
            method="GET" 
            path="/oracle/test_connection" 
            description="Teste la connexion à la base de données Oracle"
            params={[]}
          >
            <button 
              style={{ ...styles.button, ...(connectionLoading ? styles.buttonDisabled : {}) }}
              onClick={testConnection}
              disabled={connectionLoading}
            >
              {connectionLoading ? 'Test en cours...' : 'Tester Connexion'}
            </button>
            {connectionResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(connectionResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

          <EndpointCard 
            method="GET" 
            path="/oracle/exports_list" 
            description="Liste tous les fichiers Excel exportés"
            params={[]}
          >
            <button 
              style={{ ...styles.button, ...(exportsListLoading ? styles.buttonDisabled : {}) }}
              onClick={testExportsList}
              disabled={exportsListLoading}
            >
              {exportsListLoading ? 'Chargement...' : 'Lister les Exports'}
            </button>
            {exportsListResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(exportsListResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

          <EndpointCard 
            method="GET" 
            path="/oracle/download_oracle_export/{filename}" 
            description="Télécharge un fichier Excel exporté"
            params={[
              { name: 'filename', type: 'path', description: 'Nom du fichier à télécharger', required: true }
            ]}
          >
            <div style={styles.param}>
              <label style={styles.label}>Filename:</label>
              <input 
                type="text" 
                style={styles.input}
                value={downloadFilename}
                onChange={(e) => setDownloadFilename(e.target.value)}
                placeholder="ex: oracle_export.xlsx"
              />
            </div>
            <button 
              style={{ ...styles.button, ...(downloadLoading || !downloadFilename ? styles.buttonDisabled : {}) }}
              onClick={testDownload}
              disabled={downloadLoading || !downloadFilename}
            >
              {downloadLoading ? 'Téléchargement...' : 'Télécharger'}
            </button>
            {downloadResponse && (
              <div style={styles.response}>
                <div style={styles.responseTitle}>Réponse:</div>
                <pre style={styles.pre}>{JSON.stringify(downloadResponse, null, 2)}</pre>
              </div>
            )}
          </EndpointCard>

        </div>
      )}

      <div style={{ marginTop: '40px', padding: '20px', backgroundColor: '#e3f2fd', borderRadius: '8px' }}>
        <h3>ℹ️ Information</h3>
        <p>API Base URL: <code>{API_BASE}</code></p>
        <p>Pour modifier l'URL de l'API, définissez la variable d'environnement <code>VITE_API_URL</code></p>
      </div>
    </div>
  )
}
