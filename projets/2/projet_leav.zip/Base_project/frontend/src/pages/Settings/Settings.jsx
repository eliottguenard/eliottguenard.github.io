import React, { useState } from 'react';
import './Settings.css';
import { useData } from '../../contexts/DataContext';

export default function Settings() {
  const [file, setFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null); // 'idle', 'uploading', 'success', 'error'
  const [message, setMessage] = useState('');
  const [resultData, setResultData] = useState(null);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setUploadStatus('idle');
      setMessage('');
      setResultData(null);
    }
  };

  const clearFile = () => {
    setFile(null);
    setUploadStatus('idle');
    setMessage('');
    setResultData(null);
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage("Veuillez d'abord sélectionner un fichier.");
      setUploadStatus('error');
      return;
    }

    if (!file.name.endsWith('.xlsx')) {
      setMessage("Le fichier doit obligatoirement être au format .xlsx !");
      setUploadStatus('error');
      return;
    }

    try {
      setUploadStatus('uploading');
      setMessage('Mise à jour et recalcul des affectations en cours...');

      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('http://localhost:8000/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        if (data.liaison_error) {
          setUploadStatus('error');
          setMessage(`Fichier sauvegardé, mais l'algorithme a échoué: ${data.liaison_error}`);
        } else {
          setUploadStatus('success');
          setMessage("Fichier importé avec succès. Les attributions ont été mises à jour !");
          setResultData({
            total: data.liaison_total,
            attribues: data.liaison_attribues,
            sans_vehicule: data.liaison_sans_vehicule
          });
          // setTimeout(() => window.location.reload(), 3000); // Optionnel : recharger la page pour fetcher les nouvelles data
        }
      } else {
        throw new Error(data.error || "Erreur serveur HTTP.");
      }
    } catch (err) {
      setUploadStatus('error');
      setMessage(`Impossible d'importer le fichier: ${err.message}`);
    }
  };

  return (
    <div className="settings">
      <div className="settings__header">
        <h1 className="settings__title">Paramètres & Fichiers sources</h1>
        <p className="settings__subtitle">
          Uploadez vos fichiers Excel pour mettre à jour la base de données (Préleveurs, Véhicules, Indisponibilités, Tournée).
          <br />⚠️ Le nom du fichier est critique (ex: <strong>vehicules.xlsx</strong>, <strong>indisponibilite.xlsx</strong>). L'algorithme se basera sur le fichier importé et recalculera tout le planning.
        </p>
      </div>

      <div className="settings__card">
        <h2 className="settings__card-title">Mettre à jour un fichier métier</h2>
        
        <div className="settings__upload-area">
          <div className="settings__upload-box">
            <div className="settings__upload-icon">📁</div>
            <p className="settings__upload-text">
              {file ? `Fichier prêt : ${file.name}` : "Glissez & déposez votre fichier .xlsx ici ou appuyez sur Parcourir"}
            </p>
            <input 
              type="file" 
              accept=".xlsx" 
              className="settings__file-input" 
              id="file-upload" 
              onChange={handleFileChange}
            />
            <label htmlFor="file-upload" className="btn btn-secondary settings__browse-btn">
              Parcourir...
            </label>
          </div>

          {file && (
            <div className="settings__upload-actions">
              <button className="btn btn-primary" onClick={handleUpload} disabled={uploadStatus === 'uploading'}>
                {uploadStatus === 'uploading' ? 'Traitement en cours...' : '📤 Mettre à jour la base'}
              </button>
              <button className="btn btn-danger-outline" onClick={clearFile} disabled={uploadStatus === 'uploading'}>
                Annuler
              </button>
            </div>
          )}
        </div>

        {message && (
          <div className={`settings__alert settings__alert--${uploadStatus}`}>
            {message}
          </div>
        )}

        {resultData && uploadStatus === 'success' && (
          <div className="settings__results">
            <h3>Nouveau Bilan d'affectations :</h3>
            <ul className="settings__results-list">
              <li><strong>Total Tournées :</strong> {resultData.total}</li>
              <li style={{ color: '#047857' }}><strong>Succès :</strong> {resultData.attribues} véhicules trouvés</li>
              <li style={{ color: resultData.sans_vehicule > 0 ? '#dc2626' : '#6b7280' }}>
                <strong>Échecs :</strong> {resultData.sans_vehicule} tournées non assignées
              </li>
            </ul>
            <p className="settings__refresh-hint">Veuillez rafraîchir la page (F5) pour voir les nouvelles données sur le Dashboard.</p>
          </div>
        )}
      </div>
      
      <div className="settings__docs">
        <h3>Fichiers supportés par l'algorithme :</h3>
        <ul>
          <li><strong>vehicules.xlsx</strong> : Inventaire de flotte et préférences des préleveurs.</li>
          <li><strong>indisponibilite.xlsx</strong> : Jours/semaines d'indisponibilité pour un préleveur.</li>
          <li><strong>Tournee.xlsx</strong> : Fichier quotidien recensant les tournées requises.</li>
          <li><strong>preleveurs_trimestriel (1).xlsx</strong> : Matrice périodique des agents.</li>
        </ul>
      </div>
    </div>
  );
}
