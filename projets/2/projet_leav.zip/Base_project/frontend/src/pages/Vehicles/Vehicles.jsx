import React, { useState, useEffect } from 'react'
import { useData } from '../../contexts/DataContext'
import './Vehicles.css'

export default function Vehicles() {
  const { vehicles, getAssignmentsByVehicle } = useData()
  const [selectedVehicle, setSelectedVehicle] = useState(null)
  const [maintenanceData, setMaintenanceData] = useState([])

  useEffect(() => {
    fetch('http://localhost:8000/api/vehicles/maintenance')
      .then(res => res.json())
      .then(data => setMaintenanceData(data))
      .catch(err => console.error("Erreur maintenance:", err))
  }, [])
  return (
    <div className="vehicles">
      <div className="vehicles__header">
        <h1 className="vehicles__title">Véhicules</h1>
        <p className="vehicles__subtitle">
          Parc de véhicules disponibles et leurs affectations à venir.
        </p>
      </div>

      <div className="vehicles__grid">
        {vehicles.map((vehicle, idx) => {
          const vehicleAssignments = getAssignmentsByVehicle(vehicle.id).slice(0, 3)
          const statusClass = vehicle.status === 'disponible'
            ? 'disponible'
            : vehicle.status === 'maintenance'
              ? 'maintenance'
              : 'en-tournee'

          return (
            <div
              className="vehicle-card animate-fade-in"
              key={vehicle.id}
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              <div className="vehicle-card__header">
                <div className="vehicle-card__plate">
                  <div className="vehicle-card__plate-icon">🚗</div>
                  <div className="vehicle-card__plate-info">
                    <span className="vehicle-card__plate-number">{vehicle.plate}</span>
                    <span className="vehicle-card__model">{vehicle.model}</span>
                  </div>
                </div>
                <span className={`vehicle-card__status vehicle-card__status--${statusClass}`}>
                  {vehicle.status === 'disponible' ? '✅ Opérationnel' : '🔧 En maintenance'}
                </span>
              </div>

              <div className="vehicle-card__body">

                {vehicleAssignments.length > 0 && (
                  <div className="vehicle-card__assignments">
                    <div className="vehicle-card__assignments-title">
                      Prochaines affectations
                    </div>
                    {vehicleAssignments.map((a) => (
                      <div className="vehicle-card__assignment-item" key={a.id}>
                        <span className="vehicle-card__assignment-date">
                          {new Date(a.date).toLocaleDateString('fr-FR', {
                            weekday: 'short',
                            day: 'numeric',
                            month: 'short',
                          })}
                        </span>
                        <span className="vehicle-card__assignment-collector">
                          {a.collector.avatar} {a.collector.name}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* HISTORIQUE MAINTENANCE */}
                {(() => {
                  const mInfo = maintenanceData.find(m => m.plate === vehicle.plate);
                  if (!mInfo || mInfo.maintenances.length === 0) return null;

                  return (
                    <div className="vehicle-card__assignments" style={{ marginTop: '1rem', borderTop: '1px dashed #e2e8f0', paddingTop: '1rem' }}>
                      <div className="vehicle-card__assignments-title" style={{ color: '#c0392b' }}>
                        🔧 Historique Maintenance ({mInfo.maintenances.length})
                      </div>
                      <div style={{ maxHeight: '150px', overflowY: 'auto' }}>
                        {mInfo.maintenances.map((m, mIdx) => (
                          <div key={mIdx} style={{ marginBottom: '0.8rem', padding: '0.5rem', background: '#fef2f2', borderRadius: '6px', border: '1px solid #fee2e2' }}>
                            <div style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#b91c1c' }}>
                              Du {m.debut} au {m.fin}
                            </div>
                            {m.prochaine_affectation ? (
                              <div style={{ fontSize: '0.7rem', color: '#4b5563', marginTop: '3px' }}>
                                <span style={{ fontStyle: 'italic' }}>🔄 Prochaine Affectation:</span> <br/>
                                📅 <strong>{m.prochaine_affectation.date}</strong> - {m.prochaine_affectation.tournee} ({m.prochaine_affectation.preleveur})
                              </div>
                            ) : (
                              <div style={{ fontSize: '0.7rem', color: '#9ca3af', fontStyle: 'italic', marginTop: '3px' }}>
                                🚫 Aucune affectation après cette date
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()}

                {vehicle.status === 'maintenance' && (
                  <div className="vehicle-card__assignments">
                    <div style={{
                      fontSize: 'var(--font-size-xs)',
                      color: 'var(--color-danger)',
                      padding: 'var(--spacing-sm) 0',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 'var(--spacing-xs)',
                    }}>
                      🔧 Véhicule en maintenance – non disponible pour affectation
                    </div>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
