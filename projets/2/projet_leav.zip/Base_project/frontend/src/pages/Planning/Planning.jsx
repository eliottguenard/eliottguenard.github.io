import React, { useState } from 'react'
import CalendarView from '../../components/CalendarView/CalendarView'
import FilterBar from '../../components/FilterBar/FilterBar'
import './Planning.css'

export default function Planning() {
  const [filters, setFilters] = useState({
    collector: '',
    vehicle: '',
    zone: '',
  })

  return (
    <div className="planning">
      <div className="planning__header">
        <h1 className="planning__title">Planning hebdomadaire</h1>
        <p className="planning__subtitle">
          Visualisez les affectations véhicules-préleveurs pour chaque jour de la semaine.
        </p>
      </div>

      <FilterBar filters={filters} onFilterChange={setFilters} />

      <CalendarView
        filterCollector={filters.collector}
        filterVehicle={filters.vehicle}
        filterZone={filters.zone}
      />
    </div>
  )
}
