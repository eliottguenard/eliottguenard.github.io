# -*- coding: utf-8 -*-
"""
Created on Mon Feb  2 12:33:16 2026

@author: eguena01
"""

# ================================
# Librairies
# ================================

import pandas as pd  # manipulation des dataframes
from sklearn import metrics  # évaluation des modèles
from sklearn.model_selection import train_test_split  # séparation train/test
from sklearn.linear_model import LogisticRegression  # modèle de régression logistique
import numpy as np  # calculs numériques
import matplotlib.pyplot as plt  # visualisation
import seaborn as sns  # visualisation avancée
from sklearn.metrics import classification_report  # rapport de classification


# ================================
# Importation des jeux de données
# ================================

base_campagne = "base_campagne.csv"
df_campagne = pd.read_csv(base_campagne, sep=",", encoding="utf-8")  # chargement du fichier campagne

base_finance = "base_finance.csv"
df_finance = pd.read_csv(base_finance, sep=",", encoding="utf-8")  # chargement du fichier finance


# Filtrage des âges réalistes
df_campagne = df_campagne[df_campagne["age"] <= 100]
df_campagne = df_campagne[df_campagne["age"] >= 18]

# Filtrage du genre pour garder uniquement H ou F
df_campagne = df_campagne[df_campagne["genre_naissance"].isin(["F", "H"])]

# Remplacement des valeurs inconnues par "NA"
df_campagne = df_campagne.replace("unknown", "NA")
df_campagne = df_campagne.replace("inconnu", "NA")


# ================================
# Nettoyage des données
# ================================

# Harmonisation des valeurs de genre
df_campagne["genre_naissance"] = df_campagne["genre_naissance"].replace("M", "H")

# Remplacement des valeurs vides dans la colonne geo par "Autre"
df_campagne["geo"] = df_campagne["geo"].replace("", "Autre")

# On s'assure de nouveau que l'âge est inférieur ou égal à 100
df_campagne = df_campagne[df_campagne["age"] <= 100]


# ================================
# Test de corrélation (Ki2 pour les variables numériques)
# ================================

# Création de la matrice de corrélation entre variables numériques
matrix = df_campagne.select_dtypes(include="number").corr()

# Conversion en format long pour faciliter l'analyse
corr_long = (
    matrix
    .reset_index()
    .melt(
        id_vars="index",
        var_name="Variable B",
        value_name="Correlation"
    )
    .rename(columns={"index": "Variable A"})
)

# Suppression des auto-corrélations (corrélation d'une variable avec elle-même)
corr_long = corr_long[
    corr_long["Variable A"] != corr_long["Variable B"]
]

# Suppression des doublons A-B / B-A
corr_long["pair"] = corr_long.apply(
    lambda x: "_".join(sorted([x["Variable A"], x["Variable B"]])),
    axis=1
)

corr_long = corr_long.drop_duplicates("pair").drop(columns="pair")

# Tri décroissant par corrélation
corr_long = corr_long.sort_values("Correlation", ascending=False)

# Affichage des 10 corrélations les plus fortes
corr_long.head(10)

print(corr_long)


# ================================
# Préparation à la classification
# ================================

# Merge des données campagne et finance sur l'année et le mois
df = df_campagne.merge(
    df_finance,
    how='left',                     # jointure à gauche pour garder toutes les lignes de df_campagne
    left_on=['annee_contact', 'mois_contact'],   # clés dans df_campagne
    right_on=['annee', 'mois']       # clés correspondantes dans df_finance
)

# Création des tranches d'âge
bins = [0, 18, 25, 30, 35, 40, 45, 50, 55, 65, 100]
labels = [
    "-18", "18-25", "25-30", "30-35", "35-40",
    "40-45", "45-50", "50-55", "55-65", "65+"
]

df["tranche_age"] = pd.cut(
    df["age"],
    bins=bins,
    labels=labels,
    right=False
)

# Conversion des colonnes numériques en format numérique
df["duree_appel"] = pd.to_numeric(df["duree_appel"], errors="coerce")
df["croissance_emploi"] = pd.to_numeric(df["croissance_emploi"], errors="coerce")
df["IPC"] = pd.to_numeric(df["IPC"], errors="coerce")
df["indic_confiance"] = pd.to_numeric(df["indic_confiance"], errors="coerce")

# Création de tranches pour la durée d'appel
bins = [0, 3, 1000]
labels = [
    "moins de 3 min",
    "Appels de + de 3 minutes"
]

df["tranche_duree_appel"] = pd.cut(
    df["duree_appel"],
    bins=bins,
    labels=labels,
    right=False
)

# Création de catégories pour le nombre d'enfants
bins = [0, 1, 2, 3, 4, 5, 100]
labels = ["1", "2", "3", "4", "5", "5+"]

df["tranche_enfant"] = pd.cut(
    df["enfant"],
    bins=bins,
    labels=labels,
    right=False
)

# Normalisation de certaines variables numériques
cols = ["nb_contact", "croissance_emploi", "IPC", "indic_confiance"]
df[cols] = (df[cols] - df[cols].mean()) / df[cols].std()

# Suppression de colonnes inutiles
df = df.drop(columns=["annee_contact", "mois_contact", "annee", "age", "enfant", "duree_appel", "ID", "IPC"])

# Conversion des variables catégorielles en variables dummy (one-hot encoding)
df_pivot = pd.get_dummies(df, columns=[
    "souscription", "tranche_age","genre_naissance","geo","tranche_enfant",
    "emploi","situation","education","defaut_paiement","pret_immo",
    "credit_conso","contact_tel","jour_contact","contact_mois_suiv",
    "contacts_camp_prec","ancienne_campagne","mois","tranche_duree_appel"
])

# Suppression des variables corrélées pour éviter la multicolinéarité
# On a observé que IPC et croissance_emploi étaient fortement corrélées
df_pivot = df_pivot.drop(columns=["souscription_non"])


# ================================
# RÉGRESSION LOGISTIQUE
# ================================

# Définition des variables explicatives (X) et cible (y)
X = df_pivot.drop(columns=["souscription_oui"])
y = df_pivot["souscription_oui"]

# Séparation des données en train et test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=40)

# Nettoyage : suppression des colonnes avec une seule valeur
cols = X_train.loc[:, X_train.nunique() > 1].columns
X_train = X_train[cols]
X_test = X_test[cols]

# Instanciation du modèle
logreg = LogisticRegression(random_state=4, max_iter=5000)

# Entraînement du modèle
logreg.fit(X_train, y_train)

# Prédiction sur le jeu de test
y_pred = logreg.predict(X_test)

# Matrice de confusion
cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
cnf_matrix

# Affichage de la matrice de confusion
class_names = [0, 1]  # noms des classes
fig, ax = plt.subplots()
tick_marks = np.arange(len(class_names))
plt.xticks(tick_marks, class_names)
plt.yticks(tick_marks, class_names)

# Création de la heatmap
class_names = ["Pas de souscription", "Souscription"]
sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu", fmt='g')
ax.xaxis.set_label_position("top")
plt.xticks(ticks=np.arange(len(class_names)) + 0.5, labels=class_names, fontsize=10)
plt.yticks(ticks=np.arange(len(class_names)) + 0.5, labels=class_names, fontsize=10)
plt.tight_layout()
plt.title('Matrice de Confusion', y=1.1)
plt.ylabel('Réels')
plt.xlabel('Predictions')

# Rapport de classification
target_names = ['pas Souscription', 'Souscription']
print(classification_report(y_test, y_pred, target_names=target_names))

# Probabilités pour la courbe ROC
y_pred_proba = logreg.predict_proba(X_test)[:, 1]

# Courbe ROC
fpr, tpr, _ = metrics.roc_curve(y_test, y_pred_proba)
auc = metrics.roc_auc_score(y_test, y_pred_proba)

plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
plt.plot([0, 1], [0, 1], linestyle="--", color="grey")  # diagonale
plt.xlabel("Taux des faux positifs en %")
plt.ylabel("Taux des vrais positifs en %")
plt.title("Courbe des gains")
plt.legend(loc="lower right")
plt.tight_layout()
plt.show()


# ================================
# Calcul des Odds Ratios
# ================================

# Transformation des coefficients logistiques en odds ratios
odds_ratios = pd.DataFrame({
    "Variable": X_train.columns,
    "Odds_Ratio": np.exp(logreg.coef_[0])
})

# Tri par importance décroissante
odds_ratios = odds_ratios.sort_values("Odds_Ratio", ascending=False)

# On ne garde que les 10 plus importantes
odds_ratios = odds_ratios.head(10)

# Arrondi pour lisibilité
odds_ratios["Odds_Ratio"] = odds_ratios["Odds_Ratio"].round(3)

print(odds_ratios)
# ================================
# Courbe de Lift cumulée
# ================================

df_lift = pd.DataFrame({
    "y_true": y_test.values,
    "y_proba": y_pred_proba
})

# Trier par probabilité décroissante
df_lift = df_lift.sort_values("y_proba", ascending=False)

# % population cumulée
df_lift["pop_cum"] = np.arange(1, len(df_lift) + 1) / len(df_lift)

# % souscriptions cumulées
df_lift["sousc_cum"] = df_lift["y_true"].cumsum()
df_lift["sousc_cum_pct"] = (
    df_lift["sousc_cum"] / df_lift["y_true"].sum()
)

# Lift cumulée
df_lift["lift_cum"] = df_lift["sousc_cum_pct"] / df_lift["pop_cum"]

# Tracé
plt.figure(figsize=(6,5))
plt.plot(
    df_lift["pop_cum"],
    df_lift["lift_cum"],
    label="Lift cumulée",
    linewidth=2
)

# Lift aléatoire (=1)
plt.axhline(1, linestyle="--", color="grey", label="Aléatoire")

plt.xlabel("% population ciblée")
plt.ylabel("Lift cumulée")
plt.title("Courbe de Lift cumulée")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()


# ================================
# Visualisation
# ================================

# Extraire les colonnes des tranches d'âge
age_cols = [col for col in df_pivot.columns if col.startswith("tranche_age_")]

# Calcul du taux de souscription pour chaque tranche
taux_age = []
for col in age_cols:
    taux = df_pivot[df_pivot[col]==1]['souscription_oui'].mean()
    taux_age.append(taux)

# Créer un DataFrame pour seaborn
df_taux_age = pd.DataFrame({
    "Tranche d'âge": [col.replace("tranche_age_", "") for col in age_cols],
    "Taux de souscription": taux_age
})

# Tracer l'histogramme (barplot)
plt.figure(figsize=(10,5))
sns.barplot(x="Tranche d'âge", y="Taux de souscription", data=df_taux_age, palette="Blues_d")
plt.title("Taux de souscription par tranche d'âge")
plt.ylabel("Taux de souscription")
plt.ylim(0,1)
plt.show()