<?php
session_start();
include 'db_connect.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputPassword = isset($_POST['password']) ? $_POST['password'] : '';

    // Création du mot de passe
        if (isset($_POST['create'])) {
            if (!empty($inputPassword)) {
                // Vérifier si le mot de passe existe déjà
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM mot_de_passe WHERE mdp = :pwd");
                $stmt->execute(array('pwd' => $inputPassword));
                $count = $stmt->fetchColumn();
                
                    if ($count == 0) {
                        // Le mot de passe n'existe pas, on peut l'ajouter
                        $stmt = $pdo->prepare("INSERT INTO mot_de_passe (mdp) VALUES (:pwd)");
                        $stmt->execute(array('pwd' => $inputPassword));
                        $message = "✅ Mot de passe enregistré avec succès.";
                    } else {
                        $message = "⚠️ Ce mot de passe existe déjà dans la base de données.";
                    }
            } else {
                $message = "⚠️ Veuillez saisir un mot de passe.";
            }
    }

// Connexion
if (isset($_POST['login'])) {
    $stmt = $pdo->prepare("SELECT mdp FROM mot_de_passe");
    $stmt->execute();
    $passwords = $stmt->fetchAll(PDO::FETCH_COLUMN);

    foreach ($passwords as $index => $storedPassword) {
        if ($inputPassword === $storedPassword) {
            $_SESSION['authenticated'] = true;
            if ($index === 0) {
                header('Location: admin/index_accueil_admin.php');
            } else {
                header('Location: user/index_accueil_user.php');
            }
            exit;
        }
    }

    $message = "❌ Mot de passe incorrect.";
}

}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Page de connexion</title>
    <link rel="stylesheet" href="style_presentation.css">
</head>
<body>
    <div class="header-left">
        <form action="presentation.html" method="get"class="presentation-form">
            <button type="submit">Présentation</button>
        </form>
    </div>
    <h2>Bienvenue sur la page de connexion</h2>
    <form method="post">
        <label for="password">Mot de passe :</label>
        <div style="display: flex; align-items: center; max-width: 300px;">
            <input type="password" name="password" id="password" required style="flex: 1;">
            <button type="button"
                onclick="document.getElementById('password').type = document.getElementById('password').type === 'password' ? 'text' : 'password'"
                style="background: none; border: none; cursor: pointer;">👁️</button>
        </div>
        <br><br>
        <button type="submit" name="create">Créer mot de passe</button>
        <button type="submit" name="login">Se connecter</button>
    </form>

    <?php if (!empty($message)) : ?>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    <?php endif; ?>
</body>
</html>
