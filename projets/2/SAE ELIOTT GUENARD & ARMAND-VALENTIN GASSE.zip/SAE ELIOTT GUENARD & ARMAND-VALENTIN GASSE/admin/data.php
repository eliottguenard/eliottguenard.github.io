<?php
include './../db_connect.php';

// Nom de la table
$table = "spotify";

// Vérifie si un fichier a été envoyé et qu’il n’y a pas eu d’erreur
if (isset($_FILES['csvFile']) && $_FILES['csvFile']['error'] === UPLOAD_ERR_OK) {
    $tmpName = $_FILES['csvFile']['tmp_name'];

    if (($handle = fopen($tmpName, "r")) !== FALSE) {
        $delimiter = ",";
        $headers = fgetcsv($handle, 1000, $delimiter); // En-têtes du CSV

        // Vérifier que les en-têtes sont un tableau
        if (!is_array($headers)) {
            die("❌ Erreur : Impossible de lire les en-têtes du CSV");
        }

        // Nettoyer les en-têtes
        $headers = array_map('trim', $headers);
        
        // Construction des colonnes SQL
        $columns = implode(", ", array_map(function($h) { 
            return "`" . str_replace("`", "``", $h) . "`"; 
        }, $headers));
        $placeholders = implode(", ", array_fill(0, count($headers), "?"));

        $insertSQL = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $pdo->prepare($insertSQL);

        $success_count = 0;
        $error_count = 0;

        while (($row = fgetcsv($handle, 10000, $delimiter)) !== FALSE) {
            $cleaned = [];

            foreach ($row as $index => $value) {
                $column_name = isset($headers[$index]) ? $headers[$index] : '';
                
                if ($value === "" || $value === null) {
                    $cleaned[] = null;
                } else {
                    $value = iconv("ISO-8859-1", "UTF-8//IGNORE", $value) ?: '';
                    $value = preg_replace('/[\x00-\x1F\x7F-\x9F]/u', '', $value);
                    
                    // Conversion des types de données selon la colonne
                    $cleaned[] = convertValueForColumn($value, $column_name);
                }
            }

            try {
                $stmt->execute($cleaned);
                $success_count++;
            } catch (PDOException $e) {
                $error_count++;
                echo "❌ Erreur d'insertion : " . $e->getMessage() . "<br>";
                // Debug: afficher la ligne problématique
                echo "Ligne problématique : " . implode(" | ", $cleaned) . "<br><br>";
            }
        }

        fclose($handle);
        echo "✅ Importation terminée : $success_count lignes insérées, $error_count erreurs<br>";
    } else {
        echo "❌ Erreur lors de l'ouverture du fichier.";
    }
} else {
    echo "❌ Aucun fichier sélectionné ou erreur d'envoi.";
}

/**
 * Fonction pour convertir les valeurs selon le type de colonne
 */
function convertValueForColumn($value, $column_name) {
    // Colonnes qui doivent être des entiers
    $integer_columns = ['mode', 'key', 'time_signature', 'duration_ms', 'track_popularity'];
    
    // Colonnes qui doivent être des décimales/floats
    $float_columns = [
        'danceability', 'energy', 'loudness', 'speechiness', 'acousticness',
        'instrumentalness', 'liveness', 'valence', 'tempo'
    ];
    
    // Colonnes booléennes
    $boolean_columns = ['explicit'];
    
    // Nettoyer la valeur
    $value = trim($value);
    
    // Gérer les valeurs vides
    if ($value === '' || $value === 'NULL' || $value === 'null') {
        return null;
    }
    
    // Conversion pour les entiers
    if (in_array($column_name, $integer_columns)) {
        // Supprimer les caractères non numériques (sauf le signe moins et le point)
        $value = preg_replace('/[^\d.-]/', '', $value);
        if ($value === '' || $value === '-') {
            return null;
        }
        return (int)$value;
    }
    
    // Conversion pour les floats
    if (in_array($column_name, $float_columns)) {
        // Remplacer les virgules par des points pour les nombres français
        $value = str_replace(',', '.', $value);
        // Supprimer les caractères non numériques (sauf le signe moins et le point)
        $value = preg_replace('/[^\d.-]/', '', $value);
        if ($value === '' || $value === '-') {
            return null;
        }
        return (float)$value;
    }
    
    // Conversion pour les booléens
    if (in_array($column_name, $boolean_columns)) {
        $value = strtolower($value);
        if ($value === 'true' || $value === '1' || $value === 'yes' || $value === 'vrai') {
            return 1;
        } elseif ($value === 'false' || $value === '0' || $value === 'no' || $value === 'faux') {
            return 0;
        }
        return (bool)$value ? 1 : 0;
    }
    
    // Pour les autres colonnes, retourner la valeur telle quelle
    return $value;
}

// Nombre de lignes par page
$limit = 25;

// Récupération des paramètres 
$page   = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$sort   = isset($_GET['sort']) ? $_GET['sort'] : "";   // vide = pas de tri
$order  = isset($_GET['order']) ? strtolower($_GET['order']) : ""; // vide = pas de tri

// Colonnes autorisées pour le tri
$sortable_columns = ['track_artist', 'track_name', 'track_popularity'];

// Vérification du tri demandé
if (!in_array($sort, $sortable_columns)) {
    $sort = "";
    $order = "";
}

// Construction du ORDER BY
$orderByClause = "";
if ($sort && in_array($sort, $sortable_columns)) {
    if ($order === 'desc') {
        $orderByClause = "ORDER BY `$sort` DESC";
    } elseif ($order === 'asc') {
        $orderByClause = "ORDER BY `$sort` ASC";
    }
}

$offset = ($page - 1) * $limit;

// Clause WHERE si recherche
$whereClause = "";
$params = [];

if ($search !== "") {
    $whereClause = "WHERE `track_name` LIKE :search OR `track_artist` LIKE :search";
    $params[':search'] = "%" . $search . "%";
}

// Compter le nombre total de lignes correspondant à la recherche
$total_sql = "SELECT COUNT(*) AS total FROM `$table` $whereClause";
$total_stmt = $pdo->prepare($total_sql);
$total_stmt->execute($params);
$total_rows = $total_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = max(1, ceil($total_rows / $limit));

// Récupération des lignes avec tri (ou pas) + pagination
$sql = "SELECT * FROM `$table` $whereClause $orderByClause LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);

// Liaison des paramètres
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val, PDO::PARAM_STR);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// renommage des colonnes
$column_labels = [
    'id' => 'ID',
    'track_name' => 'Titre',
    'track_artist' => 'Artiste',
    'track_popularity' => 'Popularité',
    'track_album_name' => 'Album',
    'track_album_release_date' => 'Date de sortie',
    'playlist_name' => 'Playlist',
    'duration_ms' => 'Durée (ms)',
    'explicit' => 'Explicite',
    'danceability' => 'Danse',
    'energy' => 'Énergie',
    'key' => 'Tonalité',
    'loudness' => 'Volume',
    'mode' => 'Mode',
    'speechiness' => 'Paroles',
    'acousticness' => 'Acoustique',
    'instrumentalness' => 'Instrumental',
    'liveness' => 'Live',
    'valence' => 'Positivité',
    'tempo' => 'Tempo',
    'time_signature' => 'Signature rythmique',
    'playlist_genre' => 'Genre de la Playlist',
    'playlist_subgenre' => 'Sous-genre de la Playlist'
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>📊 Données - Spotify</title>
  <link rel="stylesheet" href="./../style.css">
</head>
<body class="zoom-75">

<!-- Header avec navigation -->
<div class="site-header">
  <div class="content-container">
    <h1 style="color: #1DB954; margin: 0;">Données Récupérées</h1>
    <div class="site-nav">
      <a href="index_accueil_admin.php">🏠 Accueil</a>
      <a href="analytics.php">📈 Graphiques & Indicateurs</a>
    </div>
  </div>
</div>

<div class="content-container">
    <h1 style="text-align: center; margin-bottom: 10px; color: #1DB954;">Gestion des titres</h1>
    
    <!-- Section des outils - CORRIGÉE -->
    <div class="content-header">
      <div class="tools-container">
        <!-- Importation CSV -->
        <div class="tool-group">
          <form class="import-form" action="" method="post" enctype="multipart/form-data">
            <input type="file" name="csvFile" accept=".csv" required>
            <button type="submit">Importer</button>
          </form>
        </div>

        <!-- Barre de recherche -->
        <div class="tool-group">
          <div class="search-bar">
            <form method="GET" action="">
              <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Titre ou artiste...">
              <button type="submit">Rechercher</button>
              <?php if ($search): ?>
                <a href="data.php" style="margin-left: 10px; color: #666; text-decoration: none; font-size: 12px;">❌ Effacer</a>
              <?php endif; ?>
            </form>
          </div>
        </div>

        <!-- Bouton Ajouter -->
        <div class="tool-group">
          <a href="create.php" class="add-button">Ajouter un titre</a>
        </div>
      </div>
    </div>

  <?php if ($rows): ?>
  <div class="table-container">
    <table>
      <tr>
        <?php
        // Colonnes à exclure
        $excluded_columns = ['track_href', 'analysis_url','uri','track_id','track_album_id','type','playlist_id','instrumentalness','mode','key','playlist_name',
      'valence',"energy",'danceability','loudness','liveness','time_signature','speechiness','acousticness'];

        foreach (array_keys($rows[0]) as $col):
            if (in_array($col, $excluded_columns)) continue;

            // Récupérer le libellé en français ou utiliser le nom de colonne par défaut
            $column_label = isset($column_labels[$col]) ? $column_labels[$col] : $col;
            
            // Classe CSS pour la largeur
            $width_class = "col-$col";

            // Tri uniquement sur colonnes autorisées
            if (in_array($col, $sortable_columns)) {
                // Cycle tri : vide → asc → desc → vide
                if ($sort === $col && $order === 'asc') {
                    $nextOrder = 'desc';
                } elseif ($sort === $col && $order === 'desc') {
                    $nextOrder = ''; // désactive le tri
                } else {
                    $nextOrder = 'asc';
                }

                // URL de tri
                $sort_url = "?search=" . urlencode($search) . "&sort=$col&order=$nextOrder&page=1";

                // Icône d'état visuel
                $arrow = '';
                if ($sort === $col) {
                    $arrow = $order === 'asc' ? '⬆️' : ($order === 'desc' ? '⬇️' : '');
                }

                echo "<th class='$width_class'><a href='$sort_url'>" . htmlspecialchars($column_label) . " $arrow</a></th>";
            } else {
                echo "<th class='$width_class'>" . htmlspecialchars($column_label) . "</th>";
            }
        endforeach;
        ?>
        <th class="col-actions">Actions</th>
      </tr>

      <?php foreach ($rows as $row): ?>
      <tr>
        <?php foreach ($row as $col => $val): ?>
          <?php if (in_array($col, $excluded_columns)) continue; ?>
          <?php $width_class = "col-$col"; ?>
          <td class="<?= $width_class ?>"><?= htmlspecialchars($val) ?></td>
        <?php endforeach; ?>
        <td class="col-actions actions">
          <a href="update.php?id=<?= $row['id'] ?>">✏️ Modifier</a>
          <a href="delete.php?id=<?= $row['id'] ?>">🗑️ Supprimer</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <!-- Pagination intelligente -->
  <div class="pagination">
    <?php
    $prev_page = $page - 1;
    $next_page = $page + 1;

    if ($page > 1) {
        echo '<a href="?page=' . $prev_page . '&search=' . urlencode($search) . '&sort=' . $sort . '&order=' . $order . '">⬅️ Précédent</a>';
    }

    $start = max(1, $page - 2);
    $end = min($total_pages, $page + 2);

    if ($start > 1) {
        echo '<a href="?page=1&search=' . urlencode($search) . '&sort=' . $sort . '&order=' . $order . '">1</a>';
        if ($start > 2) echo '<span class="dots">...</span>';
    }

    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $page ? 'active' : '';
        echo '<a class="' . $active . '" href="?page=' . $i . '&search=' . urlencode($search) . '&sort=' . $sort . '&order=' . $order . '">' . $i . '</a>';
    }

    if ($end < $total_pages) {
        if ($end < $total_pages - 1) echo '<span class="dots">...</span>';
        echo '<a href="?page=' . $total_pages . '&search=' . urlencode($search) . '&sort=' . $sort . '&order=' . $order . '">' . $total_pages . '</a>';
    }

    if ($page < $total_pages) {
        echo '<a href="?page=' . $next_page . '&search=' . urlencode($search) . '&sort=' . $sort . '&order=' . $order . '">Suivant ➡️</a>';
    }
    ?>
  </div>

  <?php else: ?>
    <div style="text-align: center; padding: 40px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
      <p style="font-size: 18px; color: #666;">
        Aucune donnée trouvée <?= $search ? "pour « " . htmlspecialchars($search) . " »" : "" ?>.
      </p>
      <?php if ($search): ?>
        <a href="data.php" class="add-button">📋 Voir tous les titres</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</div>

</body>
</html>