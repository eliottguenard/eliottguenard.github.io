<?php

include './../db_connect.php';

//////////////////////////////||||||||||||||||||||||||||||||||||||||||||||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
////////////// -------------- Récupération des données pour les graphiques -------------- \\\\\\\\\\\\\\
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\||||||||||||||||||||||||||||||||||||||||||||//////////////////////////////

// pour les stat-card
$stats_sql = "
    SELECT 
        COUNT(*) as total_tracks,
        COUNT(DISTINCT track_artist) as total_artists,
        AVG(duration_ms/60000) as avg_duration
    FROM spotify
";
$stats_stmt = $pdo->query($stats_sql);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Top 10 des artistes avec le plus de chansons populaires (popularité > 80)
$artists_sql = "
    SELECT track_artist, COUNT(*) as track_count 
    FROM spotify 
    WHERE track_popularity > 68
    GROUP BY track_artist 
    ORDER BY track_count DESC 
    LIMIT 10
";
$artists_stmt = $pdo->query($artists_sql);
$top_artists = $artists_stmt->fetchAll(PDO::FETCH_ASSOC);

// Popularité moyenne par genre
$genres_sql = "
    SELECT 
        playlist_genre_combined as playlist_genre, 
        AVG(track_popularity) as avg_popularity,
        COUNT(*) as genre_count
    FROM (
        SELECT 
            track_popularity,
            CASE 
                WHEN playlist_genre IN ('k-pop', 'korean') THEN 'k-pop' /* c'est ridicule qu'ils soient pas ensemble de base */ 
                ELSE playlist_genre
            END as playlist_genre_combined
        FROM spotify 
        WHERE playlist_genre IS NOT NULL AND playlist_genre != ''
    ) as combined_genres
    GROUP BY playlist_genre_combined
    ORDER BY avg_popularity DESC
    LIMIT 15
";
$genres_stmt = $pdo->query($genres_sql);
$top_genres = $genres_stmt->fetchAll(PDO::FETCH_ASSOC);

//energy vs popularity
$energy_sql = " 
    SELECT 
        energy,
        track_popularity,
        track_name,
        track_artist
    FROM spotify
    WHERE track_popularity is not null
    AND energy is not null
    
    ";

$energy_result = $pdo->query($energy_sql);
$energy_data = $energy_result->fetchAll(PDO::FETCH_ASSOC);

//duration vs popularity - on doit recalculer car c'est en millisecondes dans la db
$duration_sql = "
    SELECT
      (round(duration_ms / 60000,1)) as duree,
      track_popularity,
      track_name,
      track_artist
    FROM spotify
    WHERE track_popularity is not null
    and duration_ms is not null
    
";

$duration_result = $pdo->query($duration_sql);
$duration_data = $duration_result->fetchAll(PDO::FETCH_ASSOC);

// Camembert - Répartition par classes de popularité
$pie_sql = "
    SELECT 
        CASE 
            WHEN track_popularity >= 80 THEN 'Très élevée (80-100)'
            WHEN track_popularity >= 60 THEN 'Élevée (60-79)'
            WHEN track_popularity >= 40 THEN 'Moyenne (40-59)'
            WHEN track_popularity >= 20 THEN 'Faible (20-39)'
            ELSE 'Très faible (0-19)'
        END as popularite_classe,
        COUNT(*) as nombre_titres,
        ROUND(AVG(track_popularity), 1) as popularite_moyenne
    FROM spotify 
    WHERE track_popularity IS NOT NULL
    GROUP BY 
        CASE 
            WHEN track_popularity >= 80 THEN 'Très élevée (80-100)'
            WHEN track_popularity >= 60 THEN 'Élevée (60-79)'
            WHEN track_popularity >= 40 THEN 'Moyenne (40-59)'
            WHEN track_popularity >= 20 THEN 'Faible (20-39)'
            ELSE 'Très faible (0-19)'
        END
    ORDER BY 
        MIN(track_popularity) DESC
";
$pie_stmt = $pdo->query($pie_sql);
$pie_data = $pie_stmt->fetchAll(PDO::FETCH_ASSOC);

// danceability vs count par groupe de popularité - AVEC CLASSES !
$danceability_count_sql = "
    SELECT 
        danceability,
        track_popularity,
        CASE 
            WHEN track_popularity <= 68 THEN 'Popularité ≤ 68'
            ELSE 'Popularité > 68'
        END as popularity_group
    FROM spotify 
    WHERE track_popularity IS NOT NULL 
    AND danceability IS NOT NULL
";
$danceability_count_result = $pdo->query($danceability_count_sql);
$danceability_count_data = $danceability_count_result->fetchAll(PDO::FETCH_ASSOC);

// loudness vs count par groupe de popularité
$loudness_count_sql = "
    SELECT 
        loudness,
        track_popularity,
        CASE 
            WHEN track_popularity <= 68 THEN 'Popularité ≤ 68'
            ELSE 'Popularité > 68'
        END as popularity_group
    FROM spotify 
    WHERE track_popularity IS NOT NULL 
    AND loudness IS NOT NULL
";
$loudness_count_result = $pdo->query($loudness_count_sql);
$loudness_count_data = $loudness_count_result->fetchAll(PDO::FETCH_ASSOC);

// graphique key (la tonalité) vs count par groupe de popularité
$key_count_sql = "
    SELECT 
        `key`,
        track_popularity,
        CASE 
            WHEN track_popularity <= 68 THEN 'Popularité ≤ 68'
            ELSE 'Popularité > 68'
        END as popularity_group
    FROM spotify 
    WHERE track_popularity IS NOT NULL 
    AND `key` IS NOT NULL
";
$key_count_result = $pdo->query($key_count_sql);
$key_count_data = $key_count_result->fetchAll(PDO::FETCH_ASSOC);

//////////////////////////////||||||||||||||||||||||||||||||||||||||||||||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
////////////// -------------- Préparation des données pour les graphiques -------------- \\\\\\\\\\\\\\
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\||||||||||||||||||||||||||||||||||||||||||||//////////////////////////////

// Popularité par genre
$canvasjs_data = [];
foreach (array_reverse($top_genres) as $genre) {
    $canvasjs_data[] = [
        'y' => (float)number_format($genre['avg_popularity'], 1),
        'label' => number_format($genre['avg_popularity'], 1) . "/100",
        'indexLabel' => $genre['playlist_genre'] . " (" . $genre['genre_count'] . " titres)"
    ];
}

// données pour energy vs popularity AVEC DROITE DE RÉGRESSION
$energy_points = [];
$regression_points_energy = [];
$energy_equation = "";

// Variables pour le calcul de régression linéaire - Énergie
$sum_x_energy = 0;
$sum_y_energy = 0;
$sum_xy_energy = 0;
$sum_x2_energy = 0;
$n_energy = count($energy_data);

foreach ($energy_data as $track) {
    $x = (float)$track['energy'];
    $y = (int)$track['track_popularity'];
    
    $energy_points[] = [
        'x' => $x,
        'y' => $y,
        'name' => $track['track_name'] . ' - ' . $track['track_artist']
    ];
    
    // Calculs pour la régression
    $sum_x_energy += $x;
    $sum_y_energy += $y;
    $sum_xy_energy += $x * $y;
    $sum_x2_energy += $x * $x;
}

// Calcul des coefficients de la droite de régression y = ax + b - Énergie
if ($n_energy > 0) {
    $a_energy = ($n_energy * $sum_xy_energy - $sum_x_energy * $sum_y_energy) / ($n_energy * $sum_x2_energy - $sum_x_energy * $sum_x_energy);
    $b_energy = ($sum_y_energy - $a_energy * $sum_x_energy) / $n_energy;
    
    // Générer des points pour la droite de régression (x=0 et x=1)
    $regression_points_energy[] = ['x' => 0, 'y' => $b_energy];
    $regression_points_energy[] = ['x' => 1, 'y' => $a_energy * 1 + $b_energy];
    
    // Équation de la droite
    $energy_equation = "y = " . number_format($a_energy, 2) . "x + " . number_format($b_energy, 2);
}

// données pour duree vs popularity 
$duree_points = [];
foreach ($duration_data as $track) {
    $duree_points[] = [
        'x' => (float)$track['duree'],
        'y' => (int)$track['track_popularity'],
        'name' => $track['track_name'] . ' - ' . $track['track_artist']
    ];
}

// Préparation des données pour le camembert
$pie_chart_data = [];
$total_titres = 0;

foreach ($pie_data as $classe) {
    $total_titres += $classe['nombre_titres'];
}

foreach ($pie_data as $classe) {
    $pourcentage = round(($classe['nombre_titres'] / $total_titres) * 100, 1);
    $pie_chart_data[] = [
        'label' => $classe['popularite_classe'],
        'y' => (int)$classe['nombre_titres'],
        'percent' => $pourcentage,
        'popularite_moyenne' => $classe['popularite_moyenne']
    ];
}

// Préparation des données pour le graphique danceability vs count - AVEC CLASSES
$danceability_low_pop = []; // Popularité ≤ 68
$danceability_high_pop = []; // Popularité > 68

// on initialise les classes de danceability de 0.0 à 1.0 avec un intervalle de 0.1
for ($i = 0; $i < 10; $i++) {
    $min = $i / 10;
    $max = ($i + 1) / 10;
    $class_label = number_format($min, 1) . " - " . number_format($max, 1);
    
    $danceability_low_pop[$class_label] = 0;
    $danceability_high_pop[$class_label] = 0;
}

// Remplir avec les données réelles
foreach ($danceability_count_data as $row) {
    $danceability_val = (float)$row['danceability'];
    
    // Déterminer la classe de danceability
    $class_index = floor($danceability_val * 10);
    if ($class_index >= 10) $class_index = 9; // Pour gérer la valeur exacte 1.0
    
    $min = $class_index / 10;
    $max = ($class_index + 1) / 10;
    $class_label = number_format($min, 1) . " - " . number_format($max, 1);
    
    if ($row['popularity_group'] === 'Popularité ≤ 68') {
        $danceability_low_pop[$class_label] += 1;
    } else {
        $danceability_high_pop[$class_label] += 1;
    }
}

// Préparer les données pour CanvasJS
$danceability_count_points_low = [];
$danceability_count_points_high = [];

foreach ($danceability_low_pop as $class_label => $count) {
    $danceability_count_points_low[] = [
        'label' => $class_label,
        'y' => $count
    ];
}

foreach ($danceability_high_pop as $class_label => $count) {
    $danceability_count_points_high[] = [
        'label' => $class_label,
        'y' => $count
    ];
}

// Préparation des données pour le graphique loudness vs count - AVEC CLASSES
$loudness_low_pop = []; // Popularité ≤ 68
$loudness_high_pop = []; // Popularité > 68

// Initialiser les classes de loudness de -50 à 2 avec un intervalle de 5
$loudness_min = -50;
$loudness_max = 2;
$loudness_interval = 5;

for ($i = $loudness_min; $i < $loudness_max; $i += $loudness_interval) {
    $min = $i;
    $max = $i + $loudness_interval;
    $class_label = $min . " - " . $max . " dB";
    
    $loudness_low_pop[$class_label] = 0;
    $loudness_high_pop[$class_label] = 0;
}

// Remplir avec les données réelles
foreach ($loudness_count_data as $row) {
    $loudness_val = (float)$row['loudness'];
    
    // Déterminer la classe de loudness
    $class_index = floor(($loudness_val - $loudness_min) / $loudness_interval);
    $min = $loudness_min + ($class_index * $loudness_interval);
    $max = $min + $loudness_interval;
    $class_label = $min . " - " . $max . " dB";
    
    if ($row['popularity_group'] === 'Popularité ≤ 68') {
        $loudness_low_pop[$class_label] += 1;
    } else {
        $loudness_high_pop[$class_label] += 1;
    }
}

// Préparer les données pour CanvasJS
$loudness_count_points_low = [];
$loudness_count_points_high = [];

foreach ($loudness_low_pop as $class_label => $count) {
    $loudness_count_points_low[] = [
        'label' => $class_label,
        'y' => $count
    ];
}

foreach ($loudness_high_pop as $class_label => $count) {
    $loudness_count_points_high[] = [
        'label' => $class_label,
        'y' => $count
    ];
}

// Préparation des données pour le graphique key vs count - AVEC CLASSES
$key_low_pop = []; // Popularité ≤ 68
$key_high_pop = []; // Popularité > 68

// Correspondance des valeurs de key avec les noms des notes
$key_names = [
    0 => 'C',
    1 => 'C♯/D♭',
    2 => 'D',
    3 => 'D♯/E♭',
    4 => 'E',
    5 => 'F',
    6 => 'F♯/G♭',
    7 => 'G',
    8 => 'G♯/A♭',
    9 => 'A',
    10 => 'A♯/B♭',
    11 => 'B'
];

// Initialiser toutes les keys de 0 à 11
for ($i = 0; $i <= 11; $i++) {
    $key_label = $key_names[$i] . " (" . $i . ")";
    $key_low_pop[$key_label] = 0;
    $key_high_pop[$key_label] = 0;
}

// Remplir avec les données réelles
foreach ($key_count_data as $row) {
    $key_val = (int)$row['key'];
    $key_label = $key_names[$key_val] . " (" . $key_val . ")";
    
    if ($row['popularity_group'] === 'Popularité ≤ 68') {
        $key_low_pop[$key_label] += 1;
    } else {
        $key_high_pop[$key_label] += 1;
    }
}

// Préparer les données pour CanvasJS
$key_count_points_low = [];
$key_count_points_high = [];

foreach ($key_low_pop as $key_label => $count) {
    $key_count_points_low[] = [
        'label' => $key_label,
        'y' => $count
    ];
}

foreach ($key_high_pop as $key_label => $count) {
    $key_count_points_high[] = [
        'label' => $key_label,
        'y' => $count
    ];
}
?>
 
<!--/////////////////////////||||||||||||||||||||||||||||||||||||||||||||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
/////////////////// -------------------- Organisation de la page -------------------- \\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\||||||||||||||||||||||||||||||||||||||||||||////////////////////////// -->

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>📈 Analyse - Spotify</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
  <script src="https://cdn.canvasjs.com/jquery.canvasjs.min.js"></script>
  <link rel="stylesheet" href="./../style.css">
</head>
<body>
  <header>
    <div class="header">
      <h1 style="text-align: center; color: #1DB954; margin: 0;">Données d'analyse Spotify</h1>
      <nav>
        <a href="index_accueil_admin.php">🏠 Accueil</a>
        <a href="data.php">📊 Visualisation et modification des données</a>
      </nav>
    </div>
  </header>

  <div class="container">
    <!-- Cartes de statistiques -->
    <div class="stats-grid">
      <div class="stat-card">
        <h3>Total des titres</h3>
        <div class="value"><?= number_format($stats['total_tracks']) ?></div>
      </div>
      <div class="stat-card">
        <h3>Artistes uniques</h3>
        <div class="value"><?= number_format($stats['total_artists']) ?></div>
      </div>
      <div class="stat-card">
        <h3>Durée moyenne d'une chanson (min)</h3>
        <div class="value"><?= number_format($stats['avg_duration'], 1) ?></div>
      </div>
    </div>

    <!-- Graphiques -->
    <div class="charts-grid">
      <!-- Graphique Camembert - Répartition par classes de popularité -->
      <div class="chart-container-full-width">
        <h2 style="text-align:center">Répartition des titres par classe de popularité</h2>
        <div id="pieChartContainer" style="height: 500px; width: 100%;"></div>
      </div>

      <div>
        <h3 class = "infos-analyse">On séparera ici la popularité en popularité haute (>68) et basse (<=68) 
        en accordance avec les jeux de données.
        </h3>
      </div>

      <!-- Danceability vs Count par groupe de popularité -->
      <div class="chart-container-full-width">
        <h2 style="text-align:center">Distribution de la Dansabilité par groupe de popularité</h2>
        <div id="danceabilityCountChartContainer" style="height: 500px; width: 100%;"></div>
      </div>

      <!-- Top 10 Artistes avec chansons populaires -->
      <div class="chart-container">
        <h2>Top 10 des Artistes avec le plus de chansons à popularité haute (>68)</h2>
        <canvas id="artistsChart"></canvas>
      </div>

      <!-- Popularité moyenne par Genre -->
      <div class="chart-container">
        <h2>Tri des genres selon leur popularité moyenne</h2>
        <div id="chartContainer" style="height: 370px; width: 100%;"></div>
      </div>

      <!--Loudness vs Count par groupe de popularité -->
      <div class="chart-container-full-width">
        <h2 style="text-align:center">Distribution de la Loudness par groupe de popularité</h2>
        <div id="loudnessCountChartContainer" style="height: 500px; width: 100%;"></div>
      </div>

      <!-- energy vs Popularity AVEC DROITE DE RÉGRESSION -->
      <div class="chart-container">
        <h2>Relation entre Énergie et Popularité des titres</h2>
        <div id="energyChartContainer" style="height: 370px; width: 100%;"></div>
        <p style="text-align: center; color: #FF6B6B; font-weight: bold; margin-top: 10px;">
          Équation de la droite de régression : <?= $energy_equation ?>
        </p>
      </div>

      <!-- Durée vs Popularity SANS DROITE DE RÉGRESSION -->
      <div class="chart-container">
        <h2>Relation entre Durée et Popularité des titres</h2>
        <div id="durationChartContainer" style="height: 370px; width: 100%;"></div>
      </div>

      <!-- Key vs Count par groupe de popularité -->
      <div class="chart-container-full-width">
        <h2>Distribution de la Key (tonalité) par groupe de popularité</h2>
        <div id="keyCountChartContainer" style="height: 500px; width: 100%;"></div>
      </div>
    </div>
  </div>

<!--//////////////////////////////||||||||||||||||||||||||||||||||||||||||||||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
/////////////////// -------------------- Les Graphiques en eux-mêmes -------------------- \\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\||||||||||||||||||||||||||||||||||||||||||||//////////////////////////////-->
  <script>
    // Graphique Top 10 Artistes avec chansons populaires
    const artistsCtx = document.getElementById('artistsChart').getContext('2d');
    const artistsChart = new Chart(artistsCtx, {
      type: 'bar',
      data: {
        labels: <?= json_encode(array_column($top_artists, 'track_artist')) ?>,
        datasets: [{
          data: <?= json_encode(array_column($top_artists, 'track_count')) ?>,
          backgroundColor: '#1DB954',
          borderColor: '#000000ff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false // pas besoin de légende
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Nombre de titres'
            }
          }
        }
      }
    });

    // Graphique CanvasJS - Popularité moyenne par genre
    window.onload = function () {
      var genreOptions = {
        animationEnabled: true,
        theme: "light2",
        axisY: {
          tickThickness: 0,
          lineThickness: 0,
          valueFormatString: " ",
          includeZero: true,
          gridThickness: 0,
          maximum: 100,
          reversed: true
        },
        axisX: {
          tickThickness: 0,
          lineThickness: 0,
          labelFontSize: 14,
          labelFontColor: "#000000ff",			
          title:"Popularité",
          titleFontColor: "#1DB954"
        },
        data: [{
          indexLabelFontSize: 14,
          toolTipContent: "<span style=\"color:#1DB954\">{indexLabel}:</span> <span style=\"color:#333\"><strong>{y} de popularité moyenne</strong></span>",
          indexLabelPlacement: "inside",
          indexLabelFontColor: "white",
          indexLabelFontWeight: 600,
          indexLabelFontFamily: "Arial",
          color: "#1DB954",
          type: "bar",
          dataPoints: <?= json_encode($canvasjs_data) ?>
        }]
      };

      $("#chartContainer").CanvasJSChart(genreOptions);

      // Graphique energy vs Popularity AVEC DROITE DE RÉGRESSION
      var energyOptions = {
        animationEnabled: true,
        theme: "light2",
        axisX: {
          title: "Énergie",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          minimum: 0,
          maximum: 1
        },
        axisY: {
          title: "Popularité",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          minimum: 0,
          maximum: 100,
          suffix: "/100"
        },
        toolTip: {
          shared: true
        },
        legend: {
          cursor: "pointer",
          verticalAlign: "bottom",
          horizontalAlign: "left",
          dockInsidePlotArea: true
        },
        data: [
          {
            type: "scatter",
            showInLegend: true,
            name: "Titres",
            markerType: "circle",
            markerSize: 5,
            color: "#1DB954",
            toolTipContent: "{name}<br>Énergie: {x}<br>Popularité: {y}/100",
            dataPoints: <?= json_encode($energy_points) ?>,
            mouseover: function(e) {
              e.dataPoint.color = "#ff0000ff";
              e.dataPoint.markerSize = 10;
              e.chart.render();
            },
            mouseout: function(e) {
                e.dataPoint.color = "#1DB954";
                e.dataPoint.markerSize = 5;
                e.chart.render();
            }
          },
          {
            type: "line",
            showInLegend: true,
            name: "Droite de régression",
            markerType: "none",
            color: "#FF6B6B",
            lineThickness: 3,
            toolTipContent: "Régression linéaire<br>Énergie: {x}<br>Popularité estimée: {y}/100",
            dataPoints: <?= json_encode($regression_points_energy) ?>
          }
        ]
      };

      $("#energyChartContainer").CanvasJSChart(energyOptions);

      // Graphique Durée vs Popularity SANS DROITE DE RÉGRESSION
      var dureeOptions = {
        animationEnabled: true,
        theme: "light2",
        axisX: {
          title: "Durée (en minutes)",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          minimum: 0,
          maximum: 25
        },
        axisY: {
          title: "Popularité",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          minimum: 0,
          maximum: 100,
          suffix: "/100"
        },
        toolTip: {
          shared: true,
          content: "{name}<br>Durée: {x} min<br>Popularité: {y}/100"
        },
        legend: {
          cursor: "pointer",
          verticalAlign: "bottom",
          horizontalAlign: "left",
          dockInsidePlotArea: true
        },
        data: [{
          type: "scatter",
          showInLegend: false,
          name: "Titres",
          markerType: "circle",
          markerSize: 5,
          color: "#1DB954",
          dataPoints: <?= json_encode($duree_points) ?>,
          mouseover: function(e) {
            e.dataPoint.color = "#ff0000ff";
            e.dataPoint.markerSize = 10;
            e.chart.render();
          },
          mouseout: function(e) {
              e.dataPoint.color = "#1DB954";
              e.dataPoint.markerSize = 5;
              e.chart.render();
          }
        }]
      };

      $("#durationChartContainer").CanvasJSChart(dureeOptions);

      // Graphique Camembert - Répartition par classes de popularité
      var pieOptions = {
          animationEnabled: true,
          backgroundColor: "#ffffff",
          subtitles: [{
              fontFamily: "Arial",
              fontColor: "#666",
              fontSize: 14
          }],
          legend: {
              fontFamily: "Arial",
              fontColor: "#333",
              fontSize: 12
          },
          data: [{
              type: "pie",
              startAngle: 45,
              showInLegend: "true",
              legendText: "{label}",
              indexLabel: "{label} - {y}",
              indexLabelFontSize: 12,
              indexLabelFontColor: "black",
              indexLabelFontWeight: "bold",
              yValueFormatString: "#,##0 titres",
              toolTipContent: "<span style='color:#1DB954'><strong>{label}</strong></span><br>{y} ({percent}%)",
              dataPoints: <?= json_encode($pie_chart_data) ?>
          }]
      };

      // couleurs customisées pour rester dans le thème
      var pieColors = ["#1DB954", "#1ed760", "#1aa34a", "#168c3d", "#127530", "#0e5e26"];
      pieOptions.data[0].dataPoints.forEach(function(dataPoint, index) {
          dataPoint.color = pieColors[index % pieColors.length];
      });

      $("#pieChartContainer").CanvasJSChart(pieOptions);

      // Danceability vs Count par groupe de popularité
      var danceabilityCountOptions = {
        animationEnabled: true,
        theme: "light2",
        axisX: {
          title: "Danceability",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          labelAngle: -45
        },
        axisY: {
          title: "Nombre de titres",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          includeZero: true
        },
        toolTip: {
          shared: true,
          content: "{name}: {y} titres"
        },
        legend: {
          cursor: "pointer",
          itemclick: function (e) {
            if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
              e.dataSeries.visible = false;
            } else {
              e.dataSeries.visible = true;
            }
            e.chart.render();
          },
          verticalAlign: "bottom",
          horizontalAlign: "center"
        },
        data: [
          {
            type: "column",
            name: "Popularité ≤ 68",
            showInLegend: true,
            color: "#F72A23",
            dataPoints: <?= json_encode($danceability_count_points_low) ?>
          },
          {
            type: "column",
            name: "Popularité > 68", 
            showInLegend: true,
            color: "#1DB954",
            dataPoints: <?= json_encode($danceability_count_points_high) ?>
          }
        ]
      };

      $("#danceabilityCountChartContainer").CanvasJSChart(danceabilityCountOptions);

      // Loudness vs Count par groupe de popularité
      var loudnessCountOptions = {
        animationEnabled: true,
        theme: "light2",
        axisX: {
          title: "Loudness (dB)",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          labelAngle: -45
        },
        axisY: {
          title: "Nombre de titres",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          includeZero: true
        },
        toolTip: {
          shared: true,
          content: "{name}: {y} titres"
        },
        legend: {
          cursor: "pointer",
          itemclick: function (e) {
            if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
              e.dataSeries.visible = false;
            } else {
              e.dataSeries.visible = true;
            }
            e.chart.render();
          },
          verticalAlign: "bottom",
          horizontalAlign: "center"
        },
        data: [
          {
            type: "column",
            name: "Popularité ≤ 68",
            showInLegend: true,
            color: "#F72A23",
            dataPoints: <?= json_encode($loudness_count_points_low) ?>
          },
          {
            type: "column",
            name: "Popularité > 68", 
            showInLegend: true,
            color: "#1DB954",
            dataPoints: <?= json_encode($loudness_count_points_high) ?>
          }
        ]
      };

      $("#loudnessCountChartContainer").CanvasJSChart(loudnessCountOptions);

      // Key vs Count par groupe de popularité
      var keyCountOptions = {
        animationEnabled: true,
        theme: "light2",
        axisX: {
          title: "Key (Tonalité)",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          labelAngle: -45
        },
        axisY: {
          title: "Nombre de titres",
          titleFontColor: "#1DB954",
          labelFontColor: "#000000ff",
          includeZero: true
        },
        toolTip: {
          shared: true,
          content: "{name}: {y} titres"
        },
        legend: {
          cursor: "pointer",
          itemclick: function (e) {
            if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
              e.dataSeries.visible = false;
            } else {
              e.dataSeries.visible = true;
            }
            e.chart.render();
          },
          verticalAlign: "bottom",
          horizontalAlign: "center"
        },
        data: [
          {
            type: "column",
            name: "Popularité ≤ 68",
            showInLegend: true,
            color: "#F72A23",
            dataPoints: <?= json_encode($key_count_points_low) ?>
          },
          {
            type: "column",
            name: "Popularité > 68", 
            showInLegend: true,
            color: "#1DB954",
            dataPoints: <?= json_encode($key_count_points_high) ?>
          }
        ]
      };

      $("#keyCountChartContainer").CanvasJSChart(keyCountOptions);
    }
  </script>
</body>
</html>