<?php
/**
 * Fichier : update.php
 * Rôle : mettre à jour un titre existant.
 */
include './../db_connect.php';

// On récupère l'id dans l'URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    die("ID manquant !");
}

// Si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $track_name = $_POST['track_name'];
    $track_artist = $_POST['track_artist'];
    $track_popularity = $_POST['track_popularity'];

    $sql = "UPDATE spotify
            SET track_name = :track_name, track_artist = :track_artist, track_popularity = :track_popularity
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':track_name' => $track_name,
        ':track_artist' => $track_artist,
        ':track_popularity' => $track_popularity,
        ':id' => $id
    ]);

    header("Location: data.php");
    exit;
}

// Sinon, on affiche le formulaire pré-rempli
$sql = "SELECT * FROM spotify WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id]);
$track = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$track) {
    die("Titre introuvable !");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>✏️ Modifier un titre - Spotify</title>
  <link rel="stylesheet" href="./../style.css">
</head>
<body>

<!-- Header avec navigation -->
<div class="site-header">
  <div class="content-container">
    <h1 style="color: #1DB954; margin: 0;">✏️ Modifier un titre</h1>
    <div class="site-nav">
      <a href="index_accueil_admin.php">🏠 Accueil</a>
      <a href="data.php">📊 Données</a>
      <a href="analytics.php">📈 Analytics</a>
    </div>
  </div>
</div>

<div class="content-container">
  <div class="form-card">
    <h1>✏️ Modifier le titre</h1>
    
    <div class="track-info">
      <strong>ID :</strong> #<?= htmlspecialchars($id) ?><br>
      <strong>Actuellement :</strong> "<?= htmlspecialchars($track['track_name']) ?>" par <?= htmlspecialchars($track['track_artist']) ?>
    </div>

    <form method="POST">
      <div class="form-group">
        <label for="track_name">Nom du titre :</label>
        <input type="text" id="track_name" name="track_name" value="<?= htmlspecialchars($track['track_name']) ?>" required>
      </div>

      <div class="form-group">
        <label for="track_artist">Artiste :</label>
        <input type="text" id="track_artist" name="track_artist" value="<?= htmlspecialchars($track['track_artist']) ?>" required>
      </div>

      <div class="form-group">
        <label for="track_popularity">Popularité :</label>
        <input type="number" id="track_popularity" name="track_popularity" value="<?= htmlspecialchars($track['track_popularity']) ?>" required min="0" max="100">
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">💾 Mettre à jour</button>
        <a href="data.php" class="btn btn-secondary">⬅️ Retour</a>
      </div>
    </form>
  </div>
</div>

</body>
</html>