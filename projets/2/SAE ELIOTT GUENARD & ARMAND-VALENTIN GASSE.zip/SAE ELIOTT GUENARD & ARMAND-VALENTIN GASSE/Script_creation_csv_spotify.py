#Script réalisé à 99% par lechat

import spotipy
from spotipy.oauth2 import SpotifyOAuth
import pandas as pd

# 🔐 Authentification
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id="TON_CLIENT_ID",
    client_secret="TON_CLIENT_SECRET",
    redirect_uri="http://localhost:8888/callback", #C’est l’URL vers laquelle Spotify redirige l’utilisateur après qu’il a autorisé l’accès à ses données.

#Elle doit être identique à celle que tu as enregistrée dans ton tableau de bord développeur.
    scope="playlist-read-private user-library-read" #accès aux playlists privées +  bibliothèque musicale
))

# 📥 Récupération des playlists
def get_all_playlists(sp):
    playlists = []
    results = sp.current_user_playlists()
    while results:
        playlists.extend(results['items'])
        if results['next']:
            results = sp.next(results)
        else:
            break
    return playlists

# 📥 Récupération des morceaux d'une playlist
def get_tracks_from_playlist(sp, playlist_id):
    tracks = []
    results = sp.playlist_tracks(playlist_id)
    while results:
        tracks.extend(results['items'])
        if results['next']:
            results = sp.next(results)
        else:
            break
    return tracks

# 📦 Collecte des données
all_data = []
playlists = get_all_playlists(sp)

for playlist in playlists:
    playlist_name = playlist['name']
    playlist_id = playlist['id']
    playlist_genre = "non renseigné" 
    playlist_subgenre = "non renseigné"
    tracks = get_tracks_from_playlist(sp, playlist_id)

    track_ids = [item['track']['id'] for item in tracks if item['track'] and item['track']['id']]
    features = sp.audio_features(track_ids)

    for item, feature in zip(tracks, features):
        track = item['track']
        if track and feature:
            all_data.append({
                'energy': feature['energy'],
                'tempo': feature['tempo'],
                'danceability': feature['danceability'],
                'playlist_genre': playlist_genre,
                'loudness': feature['loudness'],
                'liveness': feature['liveness'],
                'valence': feature['valence'],
                'track_artist': ', '.join([artist['name'] for artist in track['artists']]),
                'time_signature': feature['time_signature'],
                'speechiness': feature['speechiness'],
                'track_popularity': track['popularity'],
                'track_href': track['href'],
                'uri': track['uri'],
                'track_album_name': track['album']['name'],
                'playlist_name': playlist_name,
                'analysis_url': feature['analysis_url'],
                'track_id': track['id'],
                'track_name': track['name'],
                'track_album_release_date': track['album']['release_date'],
                'instrumentalness': feature['instrumentalness'],
                'track_album_id': track['album']['id'],
                'mode': feature['mode'],
                'key': feature['key'],
                'duration_ms': track['duration_ms'],
                'acousticness': feature['acousticness'],
                'id': feature['id'],
                'playlist_subgenre': playlist_subgenre,
                'type': track['type'],
                'playlist_id': playlist_id
            })

# 🧾 Export CSV
df = pd.DataFrame(all_data)
df.to_csv('spotify_full_export.csv', index=False, sep = ";", decimal = ".")
print("✅ Export terminé : spotify_full_export.csv")
