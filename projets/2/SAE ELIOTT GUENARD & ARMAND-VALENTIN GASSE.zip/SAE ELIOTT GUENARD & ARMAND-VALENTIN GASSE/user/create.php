<?php
/**
 * Fichier : create.php
 * Rôle : insérer un nouveau titre dans la base.
 */
include './../db_connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Récupération des champs du formulaire
    $track_name = $_POST['track_name'];
    $track_artist = $_POST['track_artist'];
    $id = $_POST['id'];
    $track_popularity = $_POST['track_popularity'];

    // Vérification que tous les champs sont renseignés
    if (empty($id)) {
        $error = "L'ID du titre est obligatoire.";
    } elseif (empty($track_name)) {
        $error = "Le nom du titre est obligatoire.";
    } elseif (empty($track_artist)) {
        $error = "Le nom de l'artiste est obligatoire.";
    } elseif (empty($track_popularity)) {
        $error = "La popularité est obligatoire.";
    } else {
        // Vérification si l'ID existe déjà
        $check_sql = "SELECT COUNT(*) FROM spotify WHERE id = :id";
        $check_stmt = $pdo->prepare($check_sql);
        $check_stmt->execute([':id' => $id]);
        $id_exists = $check_stmt->fetchColumn();

        if ($id_exists > 0) {
            $error = "Cet ID existe déjà dans la base de données. Veuillez utiliser un ID unique.";
        } else {
            // Requête SQL préparée (protection contre les injections)
            $sql = "INSERT INTO spotify (id, track_name, track_artist, track_popularity)
                    VALUES (:id, :track_name, :track_artist, :track_popularity)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':track_name' => $track_name,
                ':track_artist' => $track_artist,
                ':track_popularity' => $track_popularity
            ]);

            header("Location: data.php?success=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>➕ Ajouter un titre - Spotify</title>
  <link rel="stylesheet" href="./../style.css">
</head>
<body>

<!-- Header avec navigation -->
<div class="site-header">
  <div class="content-container">
    <h1 style="color: #1DB954; margin: 0;">Ajouter un titre</h1>
    <div class="site-nav">
      <a href="index_accueil_user.php">🏠 Accueil</a>
      <a href="data.php">📊 Visualisation et modification des données</a>
      <a href="analytics.php">📈 Graphiques & Indicateurs</a>
    </div>
  </div>
</div>

<div class="content-container">
  <div class="form-card">
    <!-- <h1>➕ Ajouter un titre Spotify</h1> -->
    
    <?php if (isset($error)): ?>
      <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #dc3545;">
        ⚠️ <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label for="id">ID du titre : <span style="color: #dc3545;">*</span></label>
        <input type="number" id="id" name="id" required min="1" placeholder="Entrez un ID unique" value="<?= isset($_POST['id']) ? htmlspecialchars($_POST['id']) : '' ?>">
        <small style="color: #666; font-size: 0.9em;">L'ID doit être unique et non déjà utilisé</small>
      </div>

      <div class="form-group">
        <label for="track_name">Nom du titre : <span style="color: #dc3545;">*</span></label>
        <input type="text" id="track_name" name="track_name" required placeholder="Entrez le nom du titre" value="<?= isset($_POST['track_name']) ? htmlspecialchars($_POST['track_name']) : '' ?>">
      </div>

      <div class="form-group">
        <label for="track_artist">Artiste : <span style="color: #dc3545;">*</span></label>
        <input type="text" id="track_artist" name="track_artist" required placeholder="Entrez le nom de l'artiste" value="<?= isset($_POST['track_artist']) ? htmlspecialchars($_POST['track_artist']) : '' ?>">
      </div>

      <div class="form-group">
        <label for="track_popularity">Popularité : <span style="color: #dc3545;">*</span></label>
        <input type="number" id="track_popularity" name="track_popularity" required min="0" max="100" placeholder="Entrez la popularité (0-100)" value="<?= isset($_POST['track_popularity']) ? htmlspecialchars($_POST['track_popularity']) : '' ?>">
        <small style="color: #666; font-size: 0.9em;">Valeur obligatoire entre 0 et 100</small>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">💾 Enregistrer</button>
        <a href="data.php" class="btn btn-secondary">⬅️ Retour</a>
      </div>
      
      <p style="text-align: center; color: #666; margin-top: 20px; font-size: 0.9em;">
        <span style="color: #dc3545;">*</span> Champs obligatoires
      </p>
    </form>
  </div>
</div>

</body>
</html>