<?php
/**
 * index.php — Page d'accueil du site Spotify
 */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>🎵 Accueil - Spotify Analytics</title>
  <link rel="stylesheet" href="./../style.css">
</head>
<body class="home-page">
  <header class="home-header">
    <div class="container">
      <h1 style="text-align: center; color: #1DB954; margin: 0;">Spotify Analytics</h1>
      <nav class="home-nav">
        <a href="data.php">📊 Visualisation des données</a>
        <a href="analytics.php">📈 Graphiques & Indicateurs</a>
      </nav>
    </div>
  </header>

  <div class="hero">
    <div class="container">
      <h1>Bienvenue sur Spotify Analytics</h1>
      <p>Explorez, analysez et gérez votre collection de musiques Spotify avec des outils puissants de visualisation et d'analyse de données.</p>
    </div>
  </div>

  <div class="container">
    <div class="features">
      <div class="feature-card">
        <h3>📊 Visualisation des données</h3>
        <p>Accédez à l'ensemble de votre collection Spotify avec des fonctionnalités de recherche, tri et pagination avancées.</p>
      </div>
      <div class="feature-card">
        <h3>📈 Analytics avancés</h3>
        <p>Découvrez des graphiques et indicateurs détaillés et réalisés automatiquement sur votre bibliothèque musicale.</p>
      </div>
      <div class="feature-card">
        <h3>🔍 Recherche intelligente</h3>
        <p>Trouvez rapidement vos titres et artistes préférés avec notre moteur de recherche performant.</p>
      </div>
    </div>
  </div>
</body>
</html>