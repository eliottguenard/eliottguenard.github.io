<?php
include './../db_connect.php';

// Récupération de l'ID depuis l'URL (compatible PHP 5+)
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    die("ID manquant.");
}

// Si confirmation via le paramètre GET ?confirm=yes
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    $stmt = $pdo->prepare("DELETE FROM spotify WHERE id = :id");
    $stmt->execute([':id' => $id]);
    
    // Redirection vers data.php après suppression
    header("Location: data.php?deleted=1");
    exit;
}

// Récupérer les infos de la ligne à afficher avant suppression
$stmt = $pdo->prepare("SELECT * FROM spotify WHERE id = :id");
$stmt->execute([':id' => $id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die("Enregistrement introuvable.");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>🗑️ Supprimer un titre - Spotify</title>
  <link rel="stylesheet" href="./../style.css">
</head>
<body>

<!-- Header avec navigation -->
<div class="site-header">
  <div class="content-container">
    <h1 style="color: #dc3545; margin: 0;">🗑️ Supprimer un titre</h1>
    <div class="site-nav">
      <a href="index_accueil_user.php">🏠 Accueil</a>
      <a href="data.php">📊 Données</a>
      <a href="analytics.php">📈 Analytics</a>
    </div>
  </div>
</div>

<div class="content-container">
  <div class="alert-card">
    <div class="warning-icon">⚠️</div>
    <h1>Confirmer la suppression</h1>
    
    <p class="confirmation-message">
      Voulez-vous vraiment supprimer définitivement ce titre ?
    </p>

    <div class="track-details">
      <ul>
        <li><strong>ID :</strong> #<?= htmlspecialchars($id) ?></li>
        <li><strong>Titre :</strong> <?= htmlspecialchars($row['track_name']) ?></li>
        <li><strong>Artiste :</strong> <?= htmlspecialchars($row['track_artist']) ?></li>
        <li><strong>Popularité :</strong> <?= htmlspecialchars($row['track_popularity']) ?></li>
      </ul>
    </div>

    <div>
      <a href="delete.php?id=<?= $id ?>&confirm=yes" class="btn btn-danger">🗑️ Oui, supprimer</a>
      <a href="data.php" class="btn btn-secondary">❌ Non, annuler</a>
    </div>
  </div>
</div>

</body>
</html>