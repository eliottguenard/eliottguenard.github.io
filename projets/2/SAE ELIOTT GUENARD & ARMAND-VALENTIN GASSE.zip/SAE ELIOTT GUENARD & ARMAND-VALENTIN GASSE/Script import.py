import csv
import mysql.connector
import re

# Liste des tables à remplir (chaque table correspond à un fichier csv du même nom)
listeFichiers = ["high_popularity_spotify_data","low_popularity_spotify_data"]

# Connexion à la base de données MySQL, nommée "bdd_spotify"
db = mysql.connector.connect(host="localhost", user="root", password="", database="bdd_spotify",charset="utf8mb4")
c = db.cursor()
c.execute("""
CREATE TABLE `spotify` (
    `energy` FLOAT NULL,
    `tempo` FLOAT NULL,
    `danceability` FLOAT NULL,
    `playlist_genre` VARCHAR(50) NULL,
    `loudness` FLOAT NULL,
    `liveness` FLOAT NULL,
    `valence` FLOAT NULL,
    `track_artist` VARCHAR(250) NOT NULL,
    `time_signature` INT NULL,
    `speechiness` FLOAT NULL,
    `track_popularity` INT NOT NULL,
    `track_href` VARCHAR(100) NULL,
    `uri` VARCHAR(50) NULL,
    `track_album_name` VARCHAR(150) NULL,
    `playlist_name` VARCHAR(50) NULL,
    `analysis_url` VARCHAR(100) NULL,
    `track_id` VARCHAR(50) NULL,
    `track_name` VARCHAR(150) NOT NULL,
    `track_album_release_date` VARCHAR(50) NULL,
    `instrumentalness` FLOAT NULL,
    `track_album_id` VARCHAR(50) NULL,
    `mode` INT NULL,
    `key` INT NULL,
    `duration_ms` FLOAT NULL,
    `acousticness` FLOAT NULL,
    `id` VARCHAR(50) NULL,
    `playlist_subgenre` VARCHAR(50) NULL,
    `type` VARCHAR(50) NULL,
    `playlist_id` VARCHAR(50) NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
""")
db.commit() # On "force" l'exécution
c.execute("CREATE TABLE `mot_de_passe` (`mdp` varchar(70)  NOT NULL)ENGINE=InnoDB DEFAULT CHARSET = latin1;")
db.commit()

print("Attention, vous devez créer un mot de passe admin ")
while True : 
    mdp = input("Veuillez saisir un mot de passe de 10 caractères : ")
    if len(mdp) == 10 :
        c.execute("insert into mot_de_passe values ('" + mdp + "')") # On insère ce tuple dans la table traitée
        db.commit() # On "force" l'insertion
        break

# On parcourt chaque table
for Fichier in listeFichiers :
    # On ouvre le fichier CSV correspondant à la table
    fichier = open(str(Fichier) + ".csv", encoding="latin1")
    
    # On crée un lecteur CSV du fichier, et on précise que le séparateur est le ";"
    lecteurCSV = csv.DictReader(fichier, delimiter=";")
    
    # Liste pour stocker chaque ligne du lecteur CSV, chaque ligne étant sous la forme de dictionnaire
    listeDicos = []
    
    # On parcourt chaque ligne du fichier CSV pour les ajouter dans "listeDicos"
    for ligne in lecteurCSV:
        listeDicos.append(ligne)

    # On parcourt ensuite chaque dictionnaire de la liste des dictionnaires
    for dictionnaire in listeDicos :
        # On crée une liste qui contiendra les valeurs à insérer dans la table
        liste = []

        # On parcourt chaque valeur du dictionnaire (donc on parcourt chaque champ)
        for valeur in dictionnaire.values() :
            if valeur == "":
                valeur = None
            else:
                try:
                    # Nettoyage des caractères illisibles (comme 0x8D)
                    valeur = valeur.encode("latin1", errors="replace").decode("latin1", errors="replace")
                    valeur = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', valeur) # Supprime les caractères de contrôle Unicode (apostrophes,etc...)
                except Exception:
                    valeur = None
            liste.append(valeur)

  
        monTuple = tuple(liste) # On transtype la liste qui contient les valeurs pour la table à remplir en un tuple
        c.execute("INSERT INTO spotify VALUES (" + ",".join(["%s"] * len(monTuple)) + ")", monTuple) # On insère ce tuple dans la table traitée et en précisant qu'il faut insérer du 'vide' lorsque la valeur est  None
        db.commit() # On "force" l'insertion

# On affiche à l'utilisateur un message de confirmation d'ajout des données
print("L'ensemble des données des fichiers csv ont bien été ajoutées à la base de données !")
