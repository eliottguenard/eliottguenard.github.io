# NOTES :
# Pour lancer le programme, il faut suivre l'une des deux options en écrivant dans le terminal :
    # OPTION 1 : 
    # python -m streamlit run "le_chemin_vers_le_fichier\nom_du_fichier.py"
    # OPTION 2 : 
    # cd "le_chemin_vers_le_fichier"
    # streamlit run nom_du_fichier.py

import streamlit as st  # Framework web pour créer l'interface
import pandas as pd     # Manipulation de données tabulaires
import requests         # Requêtes HTTP pour récupérer l'API Vélib'
import urllib.request   # Téléchargement de pages web (Wikipédia)
from bs4 import BeautifulSoup  # Parsing HTML (Wikipédia)
import folium           # Création de cartes interactives
from folium.plugins import MarkerCluster  # Plugin Folium pour regrouper les marqueurs (clusters)
from streamlit_folium import st_folium  # Intégration d'une carte Folium dans Streamlit
import matplotlib.pyplot as plt  # Visualisation (graphiques)
import time            # Utilisé pour temporiser lors de récupération des coordonnées
import re              # Expressions régulières (nettoyage texte)
from matplotlib.ticker import PercentFormatter  # Formatage axes en pourcentage

# ------------------------------------------------
# 🎯 CONFIGURATION DE LA PAGE STREAMLIT
# ------------------------------------------------
# set_page_config : titre de la page, disposition et icône
st.set_page_config(page_title="Collecte de données web", layout="wide", page_icon="📊")

# ------------------------------------------------
# Onglets / navigation (radio bouton dans la sidebar)
# ------------------------------------------------
# On propose deux pages : "Jeux Olympiques d'Été" et "Stations Vélib' Paris"
page = st.sidebar.radio("🔹 Choisir la page", ["Jeux Olympiques d'Été", "Stations Vélib' Paris"])

# -----------------------------
# 1️⃣ PAGE Jeux Olympiques d'Été
# -----------------------------
if page == "Jeux Olympiques d'Été":
    # Titre et explication (affichage HTML autorisé)
    st.title("Analyse des Jeux Olympiques d'Été")
    st.markdown(
        """🔗 Données récupérées sur la page Wikipédia des 
        <a href="https://fr.wikipedia.org/wiki/Jeux_olympiques_d'%C3%A9t%C3%A9" target="_blank">
        Jeux Olympiques d'été</a>.""",
        unsafe_allow_html=True
    )

    # ----------------------------
    # Fonction : charger_donnees_jo()
    # -> Récupère et parse la table Wikipédia des JO d'été
    # @st.cache_data : met en cache le résultat pour accélérer les appels répétés
    @st.cache_data(show_spinner=True)
    def charger_donnees_jo():
        # On ouvre la page Wikipédia et on parse le HTML
        url = "https://fr.wikipedia.org/wiki/Jeux_olympiques_d'%C3%A9t%C3%A9"
        headers = {"User-Agent": "Mozilla/5.0"} #on passe par le user agent pour contourner les protections de wikipédia
        req = urllib.request.Request(url, headers=headers)
        html = BeautifulSoup(urllib.request.urlopen(req).read(), "html.parser")
        # On cherche la première table ayant la classe 'wikitable center'
        tab = html.find('table', {'class': 'wikitable center'})
        lignes = tab.find_all('tr')

        # On prépare un DataFrame vide avec les colonnes attendues
        df = pd.DataFrame(columns=[
            "Année", "Hôte", "Dates", "Pays",
            "Nombre Total d'Athlètes", "Nombre d'Hommes", "Nombre de femmes",
            "Sports", "Épreuves", "Ville", "Latitude", "Longitude"
        ])

        # Parcours des lignes (saut de l'entête)
        for i, ligne in enumerate(lignes[1:]):
            cols = ligne.find_all('td')
            if not cols:
                continue
            # Extraction des champs avec protections si la colonne est manquante
            annee = cols[0].text.strip()
            a_tags = cols[1].find_all('a') if len(cols) > 1 else []
            # On construit l'URL de la page ville/hôte si disponible
            hote = "https://fr.wikipedia.org" + a_tags[1].get('href') if len(a_tags) >= 2 else ""
            dates = cols[2].text.strip() if len(cols) > 2 else ""
            pays = cols[3].text.strip() if len(cols) > 3 else ""
            athlètes = cols[4].text.strip() if len(cols) > 4 else ""
            nb_H = cols[5].text.strip() if len(cols) > 5 else ""
            nb_F = cols[6].text.strip() if len(cols) > 6 else ""
            sports = cols[7].text.strip() if len(cols) > 7 else ""
            épreuves = cols[8].text.strip() if len(cols) > 8 else ""
            # On ajoute la ligne au DataFrame en laissant des vides pour les coordonnées
            df.loc[i] = [annee, hote, dates, pays, athlètes, nb_H, nb_F, sports, épreuves, None, None, None]

        # Suppression d'années annulées (1ère guerre, 2ème) car il n'y a pas de données pour ces années
        df = df[~df["Année"].isin(["1916", "1940", "1944"])]
        return df

    # Chargement initial des données JO (depuis Wikipédia, caché pour performances)
    df_jo = charger_donnees_jo()

    # ----------------------------
    # Fonction : get_ville_coord(url)
    # -> Récupère la lat/lon depuis la page Wikipédia de la ville hôte
    @st.cache_data(show_spinner=True)
    def get_ville_coord(url):
        try:
            headers = {"User-Agent": "Mozilla/5.0"} #encore le user agent pour ne pas se faire arrêter par les protections de wikipédia
            req = urllib.request.Request(url, headers=headers)
            soup = BeautifulSoup(urllib.request.urlopen(req).read(), "html.parser")
            # Nom de la page (ville)
            ville = soup.find("span", {"class": "mw-page-title-main"}).text.strip()
            # Tentative de lecture des attributs data-lat / data-lon (certains templates)
            a = soup.find("a", {"data-lat": True, "data-lon": True})
            if a:
                return ville, float(a["data-lat"]), float(a["data-lon"])
            # Sinon on cherche une balise 'geo' contenant "lat;lon"
            coord = soup.find("span", {"class": "geo"})
            if coord and ";" in coord.text:
                lat, lon = coord.text.split(";") #pour qu'on ait bien la latitude et longitude séparées
                return ville, float(lat), float(lon)
            # Retourne None si non trouvé
            return ville, None, None
        except:
            # En cas d'erreur réseau/parse, renvoyer une valeur d'erreur gérable
            return "Erreur", None, None

    # On garde les coordonnées en session_state pour ne pas tout recalculer à chaque rafraîchissement
    if "df_coords" not in st.session_state:
        st.session_state.df_coords = df_jo.copy()

    # Bouton pour récupérer les coordonnées (expliquer à l'oral : action déclenchée manuellement)
    if st.button("🌐 Récupérer les coordonnées des villes"):
        progress = st.progress(0)
        df_temp = st.session_state.df_coords.copy()
        # Boucle sur les lignes pour récupérer les coordonnées une par une
        for i, row in df_temp.iterrows():
            url_ville = row["Hôte"]
            if not url_ville.startswith("https://fr.wikipedia.org/wiki/"): #histoire de récupérer que les données des bons sites
                continue
            ville, lat, lon = get_ville_coord(url_ville)
            df_temp.loc[i, ["Ville", "Latitude", "Longitude"]] = [ville, lat, lon] #on rajoute ville, lat, lon au bon endroit
            # Mise à jour de la barre de progression
            progress.progress(min((i + 1) / len(df_temp), 1.0))
            time.sleep(0.5)  # Pause pour éviter de surcharger Wikipédia
        st.session_state.df_coords = df_temp
        st.success("✅ Coordonnées récupérées avec succès !")
        st.rerun()  # Relance la page pour afficher les changements

    # On récupère la version éventuellement mise à jour
    df_jo = st.session_state.df_coords

    # ----------------------------
    # Carte : affichage des villes hôtes (si on a des lat/lon)
    # ----------------------------
    if "Latitude" in df_jo.columns and df_jo["Latitude"].notna().any():
        st.subheader("🌍 Carte interactive des villes hôtes")

        # Création de la carte globale centrée approximativement
        m = folium.Map(location=[20, 0], zoom_start=2)

        # Groupement par coordonnées identiques (car plusieurs JO dans la même ville !)
        for (lat, lon), subset in df_jo.dropna(subset=["Latitude", "Longitude"]).groupby(["Latitude", "Longitude"]):
            ville = subset.iloc[0]["Ville"]
            editions = len(subset)

            # Choix de couleur en fonction du nombre d'éditions hébergées par la ville
            if editions == 1:
                couleur = "lightblue"
            elif editions == 2:
                couleur = "green"
            else:
                couleur = "red"

            # Construction d'un popup détaillé listant les éditions
            popup = f"<b>🏙️ Ville hôte :</b> {ville}<br>"
            for _, r in subset.iterrows():
                popup += (
                    f"<hr style='margin:4px 0'>"
                    f"🏅 <b>{r['Année']}</b> — "
                    f"<a href='{r['Hôte']}' target='_blank'>Page Wikipédia</a><br>"
                    f"<b>Pays :</b> {r['Pays']}<br>"
                    f"<b>Athlètes :</b> {r["Nombre Total d'Athlètes"]}<br>"
                )

            # Ajout du marker Folium
            folium.Marker(
                [lat, lon],
                popup=folium.Popup(popup, max_width=400),
                tooltip=f"{ville} – {editions} édition(s)",
                icon=folium.Icon(color=couleur, icon="info-sign")
            ).add_to(m)

            # légende en html directement sur la page 
            legend_html = """
                <div style="
                position: fixed; 
                bottom: 10px; left: 10px; width: 130px; height: 140px; 
                border:2px solid grey; z-index:9999; font-size:14px;
                background-color:white; opacity: 0.85; padding: 10px;">
                <b>Légende</b><br>
                <i class="fa fa-map-marker fa-2x" style="color:lightblue"></i>&nbsp; 1 édition<br>
                <i class="fa fa-map-marker fa-2x" style="color:green"></i>&nbsp; 2 éditions<br>
                <i class="fa fa-map-marker fa-2x" style="color:red"></i>&nbsp; 3 éditions
                </div>
                """
            m.get_root().html.add_child(folium.Element(legend_html))

        # Intégration de la carte Folium dans Streamlit
        st_folium(m, width=750, height=550, returned_objects=[])
    else:
        st.info("Clique sur le bouton ci-dessus pour géolocaliser les villes.")

    # ----------------------------
    # Graphiques JO (matplotlib)
    # ----------------------------
    df_graph = df_jo.copy()
    # Nettoyage : extraire les chiffres des colonnes (années, sports, épreuves, athlètes)
    for col in ["Année","Sports","Épreuves","Nombre d'Hommes","Nombre de femmes","Nombre Total d'Athlètes"]:
        df_graph[col] = (df_graph[col].astype(str).str.replace(r"[^0-9]", "", regex=True).replace("", None))
        df_graph[col] = pd.to_numeric(df_graph[col], errors="coerce")

    # Tri par année et suppression des lignes incomplètes
    df_graph = df_graph.sort_values("Année")
    df_graph = df_graph.dropna(subset=["Année","Sports","Épreuves","Nombre d'Hommes","Nombre de femmes","Nombre Total d'Athlètes"], how="any")

    # Création de 2 graphiques empilés verticalement
    fig, (ax1, ax3) = plt.subplots(2, 1, figsize=(12,10))

    # 1) Évolution du nombre de sports et d'épreuves
    ax1.set_title("Évolution du nombre de sports et d'épreuves", weight="bold")
    ax1.plot(df_graph["Année"], df_graph["Sports"], marker="o", color="green", label="Sports")
    ax1.set_xlabel("Année")
    ax1.set_ylabel("Nombre de sports", color="green")
    ax1.tick_params(axis="y", labelcolor="green")
    # ax2 partage l'axe x pour afficher les épreuves
    ax2 = ax1.twinx()
    ax2.plot(df_graph["Année"], df_graph["Épreuves"], marker="s", linestyle="--", color="orange", label="Épreuves")
    ax2.set_ylabel("Nombre d'épreuves", color="orange")
    ax2.tick_params(axis="y", labelcolor="orange")
    # Légende combinée
    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc="upper left")

    # 2) Comparaison hommes / femmes / total
    ax3.set_title("Comparaison du nombre d’athlètes selon le genre", weight="bold")
    ax3.plot(df_graph["Année"], df_graph["Nombre d'Hommes"], marker="o", color="blue", label="Hommes")
    ax3.plot(df_graph["Année"], df_graph["Nombre de femmes"], marker="o", color="red", label="Femmes")
    ax3.plot(df_graph["Année"], df_graph["Nombre Total d'Athlètes"], marker="o", color="black", label="Total")
    ax3.set_xlabel("Année")
    ax3.set_ylabel("Nombre d’athlètes")
    ax3.legend()
    fig.tight_layout()
    st.pyplot(fig)

# -----------------------------
# 2️⃣ PAGE Vélib'
# -----------------------------
else:
    # Titre de la page Vélib'
    st.title("🚲 Carte et statistiques des stations Vélib' (temps réel)")

    # ----------------------------
    # Fonction : load_velib_data()
    # -> Récupère les enregistrements Vélib' via l'API opendata.paris.fr (pagination)
    # ----------------------------
    @st.cache_data(ttl=300)
    def load_velib_data():
        # URL de base de l'API (dataset Vélib' disponibilité en temps réel)
        url_base = "https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/velib-disponibilite-en-temps-reel/records"
        resultat_final = []
        # On pagine par 100 enregistrements (sécurité si dataset volumineux)
        for i in range(0,2000,100):
            temp = requests.get(f"{url_base}?limit=100&offset={i}").json()
            resultat_final += temp.get("results", [])
            # Si on reçoit moins de 100 résultats, on arrête la pagination
            if len(temp.get("results", [])) < 100:
                break
        # Normalisation JSON -> DataFrame
        df = pd.DataFrame(resultat_final)
        coords = pd.json_normalize(df["coordonnees_geo"])  # lat/lon dans sous-objet
        df = pd.concat([df, coords.rename(columns={"lat":"lat","lon":"lon"})], axis=1)
        # Renommage colonnes utiles
        df = df.rename(columns={
            "numbikesavailable":"vélos_dispos",
            "numdocksavailable":"places_libres"
        })
        # Certaines versions de l'API ont une colonne différente pour l'arrondissement : on gère les deux cas
        if "nom_arrondissement_communes" in df.columns:
            df = df.rename(columns={"nom_arrondissement_communes":"arrondissement"})
        elif "arrondissements/communes" in df.columns:
            df = df.rename(columns={"arrondissements/communes":"arrondissement"})
        # On retourne un sous-ensemble de colonnes utiles et on supprime les lignes sans géoloc
        return df[["stationcode","name","arrondissement","capacity","vélos_dispos","places_libres","mechanical","ebike","lat","lon"]].dropna(subset=["arrondissement","lat","lon"])

    # ----------------------------
    # Fonction : prepare_velib_stats(df)
    # -> Calcule des indicateurs agrégés (taux dispo par arrondissement, proportion mécaniques/électriques, stations surutilisées)
    # ----------------------------
    @st.cache_data(ttl=300)
    def prepare_velib_stats(df):
        df_graph = df.copy()
        df_graph = df_graph.dropna(subset=["arrondissement","vélos_dispos","capacity"])
        # taux_dispo : moyenne du taux de vélos disponibles par station (vélos_dispos / capacity)
        df_graph["taux_dispo"] = df_graph.apply(lambda r: r["vélos_dispos"]/r["capacity"] if r["capacity"] else 0, axis=1)
        taux_dispo = df_graph.groupby("arrondissement")["taux_dispo"].mean().sort_values(ascending=False)
        # proportions mécaniques/électriques par station (puis moyenne par arrondissement)
        df_graph["taux_mec"] = df_graph.apply(lambda r: r["mechanical"]/r["vélos_dispos"] if r["vélos_dispos"] else 0, axis=1)
        df_graph["taux_elec"] = df_graph.apply(lambda r: r["ebike"]/r["vélos_dispos"] if r["vélos_dispos"] else 0, axis=1)
        taux_arr_100 = df_graph.groupby("arrondissement")[["taux_mec","taux_elec"]].mean()
        taux_arr_100 = taux_arr_100.div(taux_arr_100.sum(axis=1), axis=0)  # mise en proportions
        # station_surutilisee : indicateur binaire si aucune place libre (places_libres == 0)
        df_graph["station_surutilisee"] = df_graph.apply(lambda r:1 if r["places_libres"]==0 else 0, axis=1)
        stations_total = df_graph.groupby("arrondissement")["stationcode"].count()
        stations_surutilisees = df_graph.groupby("arrondissement")["station_surutilisee"].sum()
        pourcentage_surutilisees = (stations_surutilisees/stations_total).sort_values(ascending=False)
        pourcentage_surutilisees_filtre = pourcentage_surutilisees[pourcentage_surutilisees>0]
        return taux_dispo, taux_arr_100, pourcentage_surutilisees_filtre

    # ----------------------------
    # Fonctions utilitaires pour la carte
    # color_marker : détermine la couleur de l'icône selon le taux de vélos disponibles
    # get_availability_category : renvoie une catégorie high/medium/low/empty pour filtrage
    # ----------------------------
    def color_marker(row):
        if row["capacity"]==0: return "gray"
        taux = row["vélos_dispos"]/row["capacity"]*100
        if taux>=75: return "green"
        elif taux>=50: return "orange"
        elif taux>0: return "red"
        return "gray"

    def get_availability_category(row):
        if row["capacity"]==0: return "empty"
        taux = row["vélos_dispos"]/row["capacity"]*100
        if taux>=75: return "high"
        elif taux>=50: return "medium"
        elif taux>0: return "low"
        return "empty"

    # ----------------------------
    # Chargement des données Vélib' (appel de la fonction)
    # ----------------------------
    df_velib = load_velib_data()
    # Calcul des statistiques agrégées
    taux_dispo, taux_arr_100, pourcentage_surutilisees_filtre = prepare_velib_stats(df_velib)

    # ----------------------------
    # Sidebar : filtres utilisateur (arrondissement et disponibilité)
    # ----------------------------
    st.sidebar.header("🔍 Filtrer")
    liste_arr = ["Toutes les stations"] + sorted(df_velib["arrondissement"].unique())
    arr = st.selectbox("Choisissez une commune / arrondissement :", liste_arr, index=0)
    if arr=="Toutes les stations":
        df_arr = df_velib
        view_mode=True
    else:
        df_arr = df_velib[df_velib["arrondissement"]==arr]
        view_mode=False

    st.sidebar.subheader("🚦 Filtrer par disponibilité")
    show_high = st.sidebar.checkbox("🟢 Haute (≥75%)", value=True)
    show_medium = st.sidebar.checkbox("🟠 Moyenne (50-74%)", value=True)
    show_low = st.sidebar.checkbox("🔴 Faible (1-49%)", value=True)
    show_empty = st.sidebar.checkbox("⚫ Vide ou hors service (0%)", value=True)

    # Application des filtres de disponibilité (on calcule d'abord la catégorie pour chaque station)
    df_filtered = df_arr.copy()
    df_filtered["category"] = df_filtered.apply(get_availability_category, axis=1)
    categories_to_show=[]
    if show_high: categories_to_show.append("high")
    if show_medium: categories_to_show.append("medium")
    if show_low: categories_to_show.append("low")
    if show_empty: categories_to_show.append("empty")
    df_filtered = df_filtered[df_filtered["category"].isin(categories_to_show)].drop(columns=["category"])

    # ----------------------------
    # Carte Vélib' : affichage des stations filtrées avec clusters
    # -> On utilise MarkerCluster pour regrouper les marqueurs proches et améliorer les performances
    # ----------------------------
    st.subheader(f"📍 {len(df_filtered)} stations" + (f" - {arr}" if not view_mode else " (toutes)"))
    if len(df_filtered) > 0:
        # Centre de la carte = moyenne des lat / lon des stations affichées
        lat_c, lon_c = df_filtered["lat"].mean(), df_filtered["lon"].mean()
        zoom = 11 if view_mode else 13

        # Création de la carte Folium
        carte = folium.Map(location=[lat_c, lon_c], zoom_start=zoom)

        # Création du MarkerCluster : tous les marqueurs seront ajoutés au cluster
        cluster = MarkerCluster().add_to(carte)

        # Parcours des stations filtrées pour créer les marqueurs
        for _, r in df_filtered.iterrows():
            popup = f"<b>{r['name']}</b><br>Vélos : {r['vélos_dispos']} / {r['capacity']}<br>Places libres : {r['places_libres']}"
            # On crée un marker avec icône colorée (selon disponibilité) et on l'ajoute au cluster
            folium.Marker(
                [r["lat"], r["lon"]],
                popup=popup,
                icon=folium.Icon(color=color_marker(r), icon="bicycle", prefix="fa")
            ).add_to(cluster)

        # Intégration de la carte clusterisée dans Streamlit
        st_folium(carte, width=None, height=500, key="map", returned_objects=[])
    else:
        st.warning("Aucune station ne correspond aux critères.")

    # ----------------------------
    # Statistiques globales (graphiques matplotlib) : inchangées
    # ----------------------------
    st.subheader("📊 Statistiques globales par arrondissement")

    # 1) Taux moyen de disponibilité
    fig1, ax1 = plt.subplots(figsize=(12, 12))
    if arr != "Toutes les stations":
        # On atténue (alpha) les barres des autres arrondissements pour mettre en valeur celui sélectionné
        alpha_values = [1.0 if idx == arr else 0.3 for idx in taux_dispo.index]
        colors1 = ["#00A3E0" for _ in taux_dispo.index]
        for i, (idx, val) in enumerate(taux_dispo.items()):
            ax1.barh(i, val, color=colors1[i], alpha=alpha_values[i])
        ax1.set_yticks(range(len(taux_dispo)))
        ax1.set_yticklabels(taux_dispo.index)
    else:
        taux_dispo.plot(kind="barh", ax=ax1, color="#00A3E0")
    ax1.set_title("Taux moyen de disponibilité", fontsize=14, fontweight='bold')
    ax1.set_xlabel("Taux de vélos disponibles")
    ax1.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax1.grid(axis='x', alpha=0.3)
    st.pyplot(fig1)

    st.markdown("---")

    # 2) Répartition mécaniques / électriques
    fig2, ax2 = plt.subplots(figsize=(12, 12))
    if arr != "Toutes les stations":
        alpha_values = [1.0 if idx == arr else 0.3 for idx in taux_arr_100.index]
        for i, idx in enumerate(taux_arr_100.index):
            alpha = alpha_values[i]
            ax2.barh(i, taux_arr_100.loc[idx, "taux_mec"], color="#00B140", alpha=alpha)
            ax2.barh(i, taux_arr_100.loc[idx, "taux_elec"], left=taux_arr_100.loc[idx, "taux_mec"], color="#00A3E0", alpha=alpha)
        ax2.set_yticks(range(len(taux_arr_100)))
        ax2.set_yticklabels(taux_arr_100.index)
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='#00B140', label='Vélos mécaniques'),
            Patch(facecolor='#00A3E0', label='Vélos électriques')
        ]
        ax2.legend(handles=legend_elements, loc='upper right')
    else:
        taux_arr_100.plot(kind="barh", stacked=True, ax=ax2, color=["#00B140", "#00A3E0"])
        ax2.legend(["Vélos mécaniques","Vélos électriques"], loc="upper right")
    ax2.set_title("Proportion de vélos mécaniques / électriques", fontsize=14, fontweight='bold')
    ax2.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax2.grid(axis='x', alpha=0.3)
    st.pyplot(fig2)

    st.markdown("---")

    # 3) Stations sur-utilisées (proportion par arrondissement)
    fig3, ax3 = plt.subplots(figsize=(12, 10))
    if arr != "Toutes les stations":
        alpha_values = [1.0 if idx == arr else 0.3 for idx in pourcentage_surutilisees_filtre.index]
        colors3 = ["#FF6F61" for _ in pourcentage_surutilisees_filtre.index]
        for i, (idx, val) in enumerate(pourcentage_surutilisees_filtre.items()):
            ax3.barh(i, val, color=colors3[i], alpha=alpha_values[i])
        ax3.set_yticks(range(len(pourcentage_surutilisees_filtre)))
        ax3.set_yticklabels(pourcentage_surutilisees_filtre.index)
    else:
        pourcentage_surutilisees_filtre.plot(kind="barh", ax=ax3, color="#FF6F61")
    ax3.set_title("Taux de stations surutilisées", fontsize=14, fontweight='bold')
    ax3.set_xlabel("Proportion de stations saturées (aucune place libre)")
    ax3.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax3.grid(axis='x', alpha=0.3)
    st.pyplot(fig3)

    # Pied de page : attribution des données et horodatage
    st.markdown("---")
    st.markdown(
        "<p style='text-align:center; font-size:14px;'>Données issues de : "
        "<a href='https://opendata.paris.fr' target='_blank'>opendata.paris.fr</a> – Vélib' en temps réel 🚲 | "
        f"Dernière mise à jour : {pd.Timestamp.now().strftime('%H:%M:%S')}</p>",
        unsafe_allow_html=True
    )
