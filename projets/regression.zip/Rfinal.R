#Pour commencer
# Sélection du répertoire de travail et importation des données
setwd("C:/Users/USER/OneDrive - Université de Poitiers/SEMESTRE 2/Stat 2 & Régression Linéaire/SAE")
train <- read.csv2("train.csv")
test <- read.csv2("test.csv")

# Remplacer les NA dans Surface.terrain par 0
train$Surface.terrain[is.na(train$Surface.terrain)] <- 0
test$Surface.terrain[is.na(test$Surface.terrain)] <- 0


# Conversion des variables nécessaires pour train
train$Code.postal <- as.numeric(as.character(train$Code.postal))
train$Valeur.fonciere <- as.numeric(as.character(train$Valeur.fonciere))
train$Surface.reelle.bati <- as.numeric(as.character(train$Surface.reelle.bati))
train$Surface.terrain <- as.numeric(as.character(train$Surface.terrain))

# Conversion des variables nécessaires pour test
test$Code.postal <- as.numeric(as.character(test$Code.postal))
test$Surface.reelle.bati <- as.numeric(as.character(test$Surface.reelle.bati))
test$Surface.terrain <- as.numeric(as.character(test$Surface.terrain))

# Créer la colonne Surface.totale comme somme de Surface.reelle.bati et Surface.terrain
train$Surface.totale <- train$Surface.reelle.bati + train$Surface.terrain
test$Surface.totale <- test$Surface.reelle.bati + test$Surface.terrain

# Définir les codes postaux pour chaque catégorie
cp_chers <- c(79460, 79000, 79180, 79230, 79510, 79410, 79270, 79420, 79800, 79370)
cp_moinschers <- c(79500, 79400, 79100, 79600, 79390)

# Filtrer les données par catégorie pour train et test
cherstrain <- train[train$Code.postal %in% cp_chers, ]
moinscherstrain <- train[train$Code.postal %in% cp_moinschers, ]
intermediairestrain <- train[!(train$Code.postal %in% c(cp_chers, cp_moinschers)), ]

cherstest <- test[test$Code.postal %in% cp_chers, ]
moinscherstest <- test[test$Code.postal %in% cp_moinschers, ]
intermediairestest <- test[!(test$Code.postal %in% c(cp_chers, cp_moinschers)), ]

# Sous-catégories pour chers et intermédiaires(train)
appart_cherstrain <- cherstrain[cherstrain$Type.local == "Appartement", ]
maison_cherstrain <- cherstrain[cherstrain$Type.local == "Maison", ]
appart_intermtrain <- intermediairestrain[intermediairestrain$Type.local == "Appartement", ]
maison_intermtrain <- intermediairestrain[intermediairestrain$Type.local == "Maison", ]


# Sous-catégories pour chers et intermédiaires(test)
appart_cherstest <- cherstest[cherstest$Type.local == "Appartement", ]
maison_cherstest <- cherstest[cherstest$Type.local == "Maison", ]
appart_intermtest <- intermediairestest[intermediairestest$Type.local == "Appartement", ]
maison_intermtest <- intermediairestest[intermediairestest$Type.local == "Maison", ]

# Calcul de la moyenne pour chaque catégorie(train)
moy_appart_cherstrain <- mean(appart_cherstrain$Valeur.fonciere)
moy_maison_cherstrain <- mean(maison_cherstrain$Valeur.fonciere)
moy_appart_intermtrain <- mean(appart_intermtrain$Valeur.fonciere)
moy_maison_intermtrain <- mean(maison_intermtrain$Valeur.fonciere)

# Calcul des quartiles pour certaines categories(train)
Q1_maison_intermtrain <- quantile(maison_intermtrain$Valeur.fonciere, 0.25, na.rm = TRUE)
Q3_maison_intermtrain <- quantile(maison_intermtrain$Valeur.fonciere, 0.75, na.rm = TRUE)

# Créer la liste des catégories à analyser(train)
categories_train <- list(
  "Appartements - Chers" = appart_cherstrain,
  "Maisons - Chers" = maison_cherstrain,
  "Appartements - Intermédiaires" = appart_intermtrain,
  "Maisons - Intermédiaires" = maison_intermtrain,
  "Moins Chers (tous types)" = moinscherstrain)

# Créer la liste des catégories à analyser
categories_test <- list(
  "Appartements - Chers" = appart_cherstest,
  "Maisons - Chers" = maison_cherstest,
  "Appartements - Intermédiaires" = appart_intermtest,
  "Maisons - Intermédiaires" = maison_intermtest,
  "Moins Chers (tous types)" = moinscherstest
  )

# Boucle d’analyse avec le modèle puissance (log-log) pour le fichier train
# Initialiser une liste vide pour stocker les résultats
resultats_train <- list()

for (cat in names(categories_train)) {
  train_cat <- categories_train[[cat]]
  
  # Modèle linéaire pour la catégorie "Moins Chers"
  if (cat == "Moins Chers (tous types)") {
    
    # Modèle linéaire pour la catégorie "Moins Chers"
    x <- train_cat$Surface.reelle.bati
    y <- train_cat$Valeur.fonciere
    
    # Calcul des variances et covariance
    varx <- var(x)
    vary <- var(y)
    covxy <- cov(x, y)
    
    # Calcul du coefficient de corrélation
    r <- covxy / (sqrt(varx * vary))
    
    # Calcul des coefficients de régression
    a <- covxy / varx  # Pente
    b <- mean(y) - a * mean(x)  # Ordonnée à l'origine
    
    cat("  r =", round(r, 4), "\n")
    cat("  a =", round(a, 4), "\n")
    cat("  b =", round(b, 4), "\n")
    cat("  Formule : y =", round(a, 4), "* x +", round(b, 4), "\n")
    
    # Sauvegarder les résultats pour "Moins Chers"
    resultats_train[[cat]] <- list(a = a, b = b, r = r)
    
  } else {
    # Modèle log-log pour les autres catégories
    
    if (cat == "Maisons - Chers") {
      x_log <- log(train_cat$Surface.totale)
    } else {
      x_log <- log(train_cat$Surface.reelle.bati)
    }
    y_log <- log(train_cat$Valeur.fonciere)
    
    varx <- var(x_log)
    vary <- var(y_log)
    covxy <- cov(x_log, y_log)
    r <- covxy / sqrt(varx * vary)
    a <- covxy / varx
    b <- mean(y_log) - a * mean(x_log)
    
    resultats_train[[cat]] <- list(a = a, b = b, r = r)
    
    # Affichage console
    cat("\n", cat, "\n")
    cat("  r =", round(r, 4), "\n")
    cat("  a =", round(a, 4), "\n")
    cat("  b =", round(b, 4), "\n")
    cat("  Formule : log(y) =", round(a, 4), "* log(x) +", round(b, 4), "\n")
  }
}

# Une fois la boucle finie, on fait un résumé des résultats en dataframe
res_df <- do.call(rbind, lapply(names(resultats_train), function(nom) {
  data <- as.data.frame(resultats_train[[nom]])
  data$Categorie_train <- nom
  return(data)
}))

# Utiliser les paramètres pour prédire la valeur foncière dans TEST
for (cat in names(categories_test)) {
  test_cat <- categories_test[[cat]]
  
  if (cat == "Moins Chers (tous types)") {
    # Modèle linéaire pour la catégorie "Moins Chers"
    x <- test_cat$Surface.reelle.bati
    y_pred <- a * x + b
    # Prédictions
    test_cat$Valeur.fonciere_pred <- y_pred
  } else {
    
    if (cat == "Maisons - Chers") {
      x_log <- log(test_cat$Surface.totale)
    } else {
      x_log <- log(test_cat$Surface.reelle.bati)
    }
    a <- resultats_train[[cat]]$a
    b <- resultats_train[[cat]]$b
    
    y_log_pred <- a * x_log + b
    test_cat$Valeur.fonciere_pred <- exp(y_log_pred)  # Revenir à l'échelle d'origine
    
  }
  # Mise à jour dans la liste
  categories_test[[cat]] <- test_cat
}


# Rassembler toutes les prédictions depuis la liste 'categories'
test_final <- do.call(rbind, categories_test)

# Ajouter les prédictions aux sous-ensembles test depuis la liste categories
appart_cherstest$Valeur.fonciere_pred <- categories_test[["Appartements - Chers"]]$Valeur.fonciere_pred
maison_cherstest$Valeur.fonciere_pred <- categories_test[["Maisons - Chers"]]$Valeur.fonciere_pred
appart_intermtest$Valeur.fonciere_pred <- categories_test[["Appartements - Intermédiaires"]]$Valeur.fonciere_pred
maison_intermtest$Valeur.fonciere_pred <- categories_test[["Maisons - Intermédiaires"]]$Valeur.fonciere_pred
moinscherstest$Valeur.fonciere_pred <- categories_test[["Moins Chers (tous types)"]]$Valeur.fonciere_pred


# Correction des valeurs aberrantes

# Appartements - Chers
index_appart_chers <- log(appart_cherstest$Surface.totale) >= 4 &
  log(appart_cherstest$Surface.totale) <= 5 &
  log(appart_cherstest$Valeur.fonciere_pred) <= 10
# Modifier uniquement ces lignes
appart_cherstest$Valeur.fonciere_pred[index_appart_chers] <- moy_appart_cherstrain

# Maisons - Chers
index_maison_chers <- log(maison_cherstest$Surface.totale) <= 3 &
  log(maison_cherstest$Surface.totale) > 0 &
  log(maison_cherstest$Valeur.fonciere_pred) >= 10 &
  log(maison_cherstest$Valeur.fonciere_pred) <= 14
# Modifier uniquement ces lignes
maison_cherstest$Valeur.fonciere_pred[index_maison_chers] <- moy_maison_cherstrain

# Appartements - Intermédiaires
index_appart_interm <- log(appart_intermtest$Surface.totale) >= 3 &
  log(appart_intermtest$Surface.totale) <= 4.5 &
  log(appart_intermtest$Valeur.fonciere_pred) <= 10
# Modifier uniquement ces lignes
appart_intermtest$Valeur.fonciere_pred[index_appart_interm] <- moy_appart_intermtrain

# Maisons - Intermédiaires
index_maison_interm1 <- log(maison_intermtest$Surface.totale) >= 3.5 &
  log(maison_intermtest$Surface.totale) <= 4.5 &
  log(maison_intermtest$Valeur.fonciere_pred) >= 0 &
  log(maison_intermtest$Valeur.fonciere_pred) <= 10
index_maison_interm2 <- log(maison_intermtest$Surface.totale) < 3.5 &
  log(maison_intermtest$Valeur.fonciere_pred) > 11
index_maison_interm3 <- log(maison_intermtest$Surface.totale) > 4.5 &
  log(maison_intermtest$Valeur.fonciere_pred) <= 11
# Modifier uniquement ces lignes(Valeur.fonciere_pred) dans test par la moyenne, le Q1 ou le Q3 dans train
maison_intermtest$Valeur.fonciere_pred[index_maison_interm1] <- moy_maison_intermtrain
maison_intermtest$Valeur.fonciere_pred[index_maison_interm2] <- Q1_maison_intermtrain
maison_intermtest$Valeur.fonciere_pred[index_maison_interm3] <- Q3_maison_intermtrain



# Créer le dataframe final avec ID et les valeurs foncières prédites
resultats_test <- data.frame(id = test_final$id, 
                             Valeur.fonciere = round(test_final$Valeur.fonciere_pred))

#Pour finir
# Exporter le fichier prediction.csv
setwd("C:/Users/USER/OneDrive - Université de Poitiers/SEMESTRE 2/Stat 2 & Régression Linéaire/SAE")
write.csv2(resultats_test, "prediction.csv", row.names = FALSE)

